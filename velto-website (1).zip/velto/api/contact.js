// Vercel Serverless Function — POST /api/contact
// Secrets are read from environment variables on the server; nothing is exposed to the browser.
import { handleContact, clientIp } from "../lib/contact.mjs";

export default async function handler(req, res) {
  res.setHeader("Cache-Control", "no-store");
  if (req.method !== "POST") {
    res.setHeader("Allow", "POST");
    return res.status(405).json({ ok: false, error: "Method not allowed." });
  }
  let body = req.body;
  if (typeof body === "string") {
    try { body = JSON.parse(body); } catch { body = null; }
  }
  const { status, json } = await handleContact({
    body,
    ip: clientIp(req.headers, req.socket?.remoteAddress),
    origin: req.headers.origin,
    host: req.headers["x-forwarded-host"] || req.headers.host,
    referer: req.headers.referer,
  });
  return res.status(status).json(json);
}
