/* =========================================================================
   VELTO — interaction & motion engine (no dependencies)
   ========================================================================= */
(() => {
  "use strict";

  const $ = (s, el = document) => el.querySelector(s);
  const $$ = (s, el = document) => Array.from(el.querySelectorAll(s));
  const root = document.documentElement;
  const mqReduce = window.matchMedia("(prefers-reduced-motion: reduce)");
  const reduce = mqReduce.matches;
  const finePointer = window.matchMedia("(hover: hover) and (pointer: fine)").matches;
  const isSmall = () => window.innerWidth < 768;
  const clamp = (v, a, b) => Math.min(b, Math.max(a, v));

  /* ---------- Loader (once per session) ---------- */
  const loader = $("[data-loader]");
  let seen = false;
  try { seen = !!sessionStorage.getItem("velto-seen"); } catch (e) {}
  const hideLoader = () => {
    if (!loader || loader.classList.contains("is-done")) return;
    loader.classList.add("is-done");
    try { sessionStorage.setItem("velto-seen", "1"); } catch (e) {}
    setTimeout(() => loader.remove(), 800);
  };
  if (loader) {
    if (seen || reduce) loader.remove();
    else {
      const start = performance.now();
      const finish = () => setTimeout(hideLoader, Math.max(0, 1350 - (performance.now() - start)));
      if (document.readyState === "complete") finish();
      else window.addEventListener("load", finish, { once: true });
      setTimeout(hideLoader, 3000); // hard cap — content is never blocked
    }
  }

  /* ---------- Smooth scroll (desktop, fine pointer only) ---------- */
  let smooth = null;
  if (!reduce && finePointer) {
    let target = window.scrollY, current = target, raf = 0, running = false;
    const max = () => document.documentElement.scrollHeight - window.innerHeight;
    const step = () => {
      current += (target - current) * 0.1;
      if (Math.abs(target - current) < 0.5) { current = target; running = false; }
      window.scrollTo(0, current);
      if (running) raf = requestAnimationFrame(step);
    };
    const onWheel = (e) => {
      if (e.ctrlKey || e.defaultPrevented || smooth.locked) return;
      // let nested scrollable areas handle their own wheel events
      let el = e.target;
      while (el && el !== document.body) {
        const st = getComputedStyle(el);
        if (/(auto|scroll)/.test(st.overflowY + st.overflowX) && (el.scrollHeight > el.clientHeight + 1 || el.scrollWidth > el.clientWidth + 1)) return;
        el = el.parentElement;
      }
      e.preventDefault();
      const delta = e.deltaMode === 1 ? e.deltaY * 32 : e.deltaMode === 2 ? e.deltaY * window.innerHeight : e.deltaY;
      if (!running) { current = window.scrollY; target = current; }
      target = clamp(target + delta, 0, max());
      if (!running) { running = true; raf = requestAnimationFrame(step); }
    };
    window.addEventListener("wheel", onWheel, { passive: false });
    window.addEventListener("scroll", () => { if (!running) { target = current = window.scrollY; } }, { passive: true });
    smooth = {
      locked: false,
      to(y) { current = window.scrollY; target = clamp(y, 0, max()); if (!running) { running = true; raf = requestAnimationFrame(step); } },
    };
    root.classList.add("has-smooth");
  }
  const scrollToEl = (el) => {
    const y = el.getBoundingClientRect().top + window.scrollY - 90;
    if (smooth) smooth.to(y); else window.scrollTo({ top: y, behavior: reduce ? "auto" : "smooth" });
  };
  document.addEventListener("click", (e) => {
    const a = e.target.closest('a[href^="#"]');
    if (!a) return;
    const id = a.getAttribute("href").slice(1);
    const el = id && document.getElementById(id);
    if (el) { e.preventDefault(); scrollToEl(el); history.replaceState(null, "", "#" + id); }
  });

  /* ---------- Header ---------- */
  const header = $("[data-header]");
  const onScrollHeader = () => header && header.classList.toggle("is-scrolled", window.scrollY > 12);
  onScrollHeader();
  window.addEventListener("scroll", onScrollHeader, { passive: true });

  // Mega menu
  const megaToggle = $("[data-mega-toggle]");
  const mega = $("[data-mega]");
  if (megaToggle && mega) {
    const li = megaToggle.closest("li");
    let t;
    const open = () => { clearTimeout(t); mega.classList.add("is-open"); megaToggle.setAttribute("aria-expanded", "true"); };
    const close = () => { mega.classList.remove("is-open"); megaToggle.setAttribute("aria-expanded", "false"); };
    const closeSoon = () => { clearTimeout(t); t = setTimeout(close, 160); };
    if (finePointer) {
      li.addEventListener("mouseenter", open);
      li.addEventListener("mouseleave", closeSoon);
    }
    megaToggle.addEventListener("click", () => (mega.classList.contains("is-open") ? close() : open()));
    li.addEventListener("focusout", (e) => { if (!li.contains(e.relatedTarget)) close(); });
    document.addEventListener("keydown", (e) => { if (e.key === "Escape" && mega.classList.contains("is-open")) { close(); megaToggle.focus(); } });
    document.addEventListener("click", (e) => { if (!li.contains(e.target)) close(); });
  }

  // Mobile menu
  const menuBtn = $("[data-menu-toggle]");
  const setMenu = (open) => {
    document.body.classList.toggle("menu-open", open);
    document.body.classList.toggle("no-scroll", open);
    if (smooth) smooth.locked = open;
    menuBtn.setAttribute("aria-expanded", String(open));
    menuBtn.setAttribute("aria-label", open ? "Close menu" : "Open menu");
  };
  if (menuBtn) {
    menuBtn.addEventListener("click", () => setMenu(!document.body.classList.contains("menu-open")));
    document.addEventListener("keydown", (e) => { if (e.key === "Escape" && document.body.classList.contains("menu-open")) { setMenu(false); menuBtn.focus(); } });
    window.addEventListener("resize", () => { if (window.innerWidth >= 1024) setMenu(false); });
  }
  $$("[data-m-toggle]").forEach((b) => {
    b.addEventListener("click", () => {
      const sub = document.getElementById(b.getAttribute("aria-controls"));
      const open = b.getAttribute("aria-expanded") !== "true";
      b.setAttribute("aria-expanded", String(open));
      sub.classList.toggle("is-open", open);
    });
  });

  /* ---------- Page transitions ---------- */
  if (!reduce) {
    document.addEventListener("click", (e) => {
      const a = e.target.closest("a[href]");
      if (!a || e.defaultPrevented || e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;
      if (a.target === "_blank" || a.hasAttribute("download")) return;
      const url = new URL(a.href, location.href);
      if (url.origin !== location.origin || url.pathname.startsWith("/api/")) return;
      if (url.pathname === location.pathname && url.search === location.search) return;
      if (!/^https?:$/.test(url.protocol)) return;
      e.preventDefault();
      document.body.classList.add("is-leaving");
      setTimeout(() => (location.href = url.href), 300);
    });
    window.addEventListener("pageshow", (e) => { if (e.persisted) { document.body.classList.remove("is-leaving"); setMenu && menuBtn && setMenu(false); } });
  }

  /* ---------- Reveal on scroll ---------- */
  const revealEls = $$("[data-reveal]");
  if ("IntersectionObserver" in window && !reduce) {
    const io = new IntersectionObserver(
      (entries) => entries.forEach((en) => { if (en.isIntersecting) { en.target.classList.add("is-in"); io.unobserve(en.target); } }),
      { rootMargin: "0px 0px -8% 0px", threshold: 0.12 }
    );
    revealEls.forEach((el) => io.observe(el));
  } else revealEls.forEach((el) => el.classList.add("is-in"));

  /* ---------- Counters ---------- */
  const counters = $$("[data-count]");
  const runCounter = (el) => {
    const end = parseFloat(el.dataset.count);
    if (reduce) { el.textContent = end.toLocaleString("en-IN"); return; }
    const dur = 1600, t0 = performance.now();
    const tick = (t) => {
      const p = clamp((t - t0) / dur, 0, 1);
      const eased = 1 - Math.pow(1 - p, 4);
      el.textContent = Math.round(end * eased).toLocaleString("en-IN");
      if (p < 1) requestAnimationFrame(tick);
    };
    el.textContent = "0";
    requestAnimationFrame(tick);
  };
  if (counters.length && "IntersectionObserver" in window) {
    const io = new IntersectionObserver((entries) => entries.forEach((en) => { if (en.isIntersecting) { runCounter(en.target); io.unobserve(en.target); } }), { threshold: 0.5 });
    counters.forEach((c) => io.observe(c));
  }

  /* ---------- Generic "in view" activation (charts, donuts) ---------- */
  const activate = (el) => {
    el.classList.add("is-in");
    $$(".donut .seg", el).forEach((c) => c.setAttribute("style", `stroke-dasharray:${c.dataset.len} 999`));
  };
  const actEls = $$("[data-xl], [data-hr], [data-vbars], .svc-panel");
  if ("IntersectionObserver" in window) {
    const io = new IntersectionObserver((entries) => entries.forEach((en) => { if (en.isIntersecting) { activate(en.target); io.unobserve(en.target); } }), { threshold: 0.25 });
    actEls.forEach((el) => io.observe(el));
  } else actEls.forEach(activate);

  /* ---------- Spotlight cards ---------- */
  if (finePointer) {
    document.addEventListener("pointermove", (e) => {
      const card = e.target.closest && e.target.closest("[data-spotlight]");
      if (!card) return;
      const r = card.getBoundingClientRect();
      card.style.setProperty("--x", `${e.clientX - r.left}px`);
      card.style.setProperty("--y", `${e.clientY - r.top}px`);
    }, { passive: true });
  }

  /* ---------- Magnetic buttons ---------- */
  if (finePointer && !reduce) {
    $$("[data-magnetic]").forEach((el) => {
      el.addEventListener("pointermove", (e) => {
        const r = el.getBoundingClientRect();
        el.style.setProperty("--bx", `${(e.clientX - r.left - r.width / 2) * 0.22}px`);
        el.style.setProperty("--by", `${(e.clientY - r.top - r.height / 2) * 0.3}px`);
      });
      el.addEventListener("pointerleave", () => { el.style.setProperty("--bx", "0px"); el.style.setProperty("--by", "0px"); });
    });
  }

  /* ---------- Scroll-driven effects (parallax, scrubbed text, process line) ---------- */
  const parallaxEls = $$("[data-parallax]");
  const scrubEls = $$("[data-scrub]").map((p) => {
    const words = p.textContent.trim().split(/\s+/);
    const hl = new Set(["technology", "business", "solutions", "partner.", "smarter,", "grow", "confidence.", "engineering,", "automation", "dependable", "partner"]);
    p.setAttribute("aria-label", p.textContent.trim());
    p.innerHTML = words.map((w) => `<span class="w${hl.has(w.toLowerCase()) ? " hl" : ""}" aria-hidden="true">${w}</span>`).join(" ");
    return { el: p, words: $$(".w", p) };
  });
  const processEls = $$("[data-process]").map((el) => ({ el, line: $(".process-line", el), steps: $$(".step", el) }));
  const hero = $("[data-hero]");
  const heroCopy = $("[data-hero-copy]");

  let ticking = false;
  const onScroll = () => {
    ticking = false;
    const vh = window.innerHeight;
    if (!reduce && !isSmall()) {
      parallaxEls.forEach((el) => {
        const r = el.getBoundingClientRect();
        if (r.bottom < -200 || r.top > vh + 200) return;
        const speed = parseFloat(el.dataset.parallax) || 0.1;
        const offset = (r.top + r.height / 2 - vh / 2) * speed;
        el.style.translate = `0 ${offset.toFixed(1)}px`;
      });
    }
    if (hero && heroCopy && !reduce) {
      const p = clamp(window.scrollY / (hero.offsetHeight || 1), 0, 1);
      heroCopy.style.transform = `translate3d(0, ${p * 80}px, 0)`;
      heroCopy.style.opacity = String(1 - p * 1.1);
    }
    scrubEls.forEach(({ el, words }) => {
      const r = el.getBoundingClientRect();
      const p = reduce ? 1 : clamp((vh * 0.85 - r.top) / (r.height + vh * 0.35), 0, 1);
      const n = Math.round(p * words.length);
      words.forEach((w, i) => (w.style.opacity = i < n ? "1" : ""));
    });
    processEls.forEach(({ el, line, steps }) => {
      const r = el.getBoundingClientRect();
      const p = reduce ? 1 : clamp((vh * 0.75 - r.top) / (r.height * 0.9), 0, 1);
      if (line) line.style.setProperty("--p", p.toFixed(3));
      steps.forEach((s, i) => s.classList.toggle("is-lit", p >= i / Math.max(steps.length - 1, 1) - 0.02));
    });
  };
  const requestTick = () => { if (!ticking) { ticking = true; requestAnimationFrame(onScroll); } };
  window.addEventListener("scroll", requestTick, { passive: true });
  window.addEventListener("resize", requestTick);
  onScroll();

  /* ---------- Hero 3D tilt (mouse-follow) ---------- */
  const tilt = $("[data-tilt]");
  if (tilt && finePointer && !reduce) {
    const inner = $(".orb-3d", tilt);
    window.addEventListener("pointermove", (e) => {
      const x = e.clientX / window.innerWidth - 0.5;
      const y = e.clientY / window.innerHeight - 0.5;
      inner.style.transform = `perspective(1200px) rotateX(${(-y * 14).toFixed(2)}deg) rotateY(${(x * 18).toFixed(2)}deg)`;
    }, { passive: true });
  }

  /* ---------- Hero network canvas (particles + connecting nodes) ---------- */
  const canvas = $("[data-network]");
  if (canvas && canvas.getContext) {
    const ctx = canvas.getContext("2d");
    let w = 0, h = 0, nodes = [], visible = true, raf = 0;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const mouse = { x: -9999, y: -9999 };
    const resize = () => {
      const r = canvas.getBoundingClientRect();
      w = r.width; h = r.height;
      canvas.width = Math.round(w * dpr); canvas.height = Math.round(h * dpr);
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      const count = Math.round(clamp((w * h) / (isSmall() ? 22000 : 15000), 18, 90));
      nodes = Array.from({ length: count }, () => ({
        x: Math.random() * w, y: Math.random() * h,
        vx: (Math.random() - 0.5) * 0.3, vy: (Math.random() - 0.5) * 0.3,
        r: Math.random() * 1.4 + 0.6,
      }));
    };
    const draw = () => {
      ctx.clearRect(0, 0, w, h);
      const maxD = isSmall() ? 95 : 135, maxD2 = maxD * maxD;
      for (const n of nodes) {
        if (!reduce) {
          n.x += n.vx; n.y += n.vy;
          if (n.x < 0 || n.x > w) n.vx *= -1;
          if (n.y < 0 || n.y > h) n.vy *= -1;
          const dx = mouse.x - n.x, dy = mouse.y - n.y, d2 = dx * dx + dy * dy;
          if (d2 < 32000) { n.x += dx * 0.004; n.y += dy * 0.004; }
        }
      }
      ctx.lineWidth = 1;
      for (let i = 0; i < nodes.length; i++) {
        const a = nodes[i];
        for (let j = i + 1; j < nodes.length; j++) {
          const b = nodes[j], dx = a.x - b.x, dy = a.y - b.y, d2 = dx * dx + dy * dy;
          if (d2 < maxD2) {
            ctx.strokeStyle = `rgba(91,140,255,${((1 - d2 / maxD2) * 0.32).toFixed(3)})`;
            ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.stroke();
          }
        }
        const mdx = a.x - mouse.x, mdy = a.y - mouse.y, md2 = mdx * mdx + mdy * mdy;
        if (md2 < 40000) {
          ctx.strokeStyle = `rgba(34,211,238,${((1 - md2 / 40000) * 0.55).toFixed(3)})`;
          ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(mouse.x, mouse.y); ctx.stroke();
        }
      }
      for (const n of nodes) {
        ctx.fillStyle = "rgba(180,205,255,0.85)";
        ctx.beginPath(); ctx.arc(n.x, n.y, n.r, 0, Math.PI * 2); ctx.fill();
      }
    };
    const loop = () => { if (visible && !document.hidden) draw(); raf = requestAnimationFrame(loop); };
    resize();
    if (reduce) draw(); else raf = requestAnimationFrame(loop);
    let rt;
    window.addEventListener("resize", () => { clearTimeout(rt); rt = setTimeout(() => { resize(); if (reduce) draw(); }, 150); });
    if ("IntersectionObserver" in window) new IntersectionObserver(([en]) => (visible = en.isIntersecting)).observe(canvas);
    if (finePointer) {
      window.addEventListener("pointermove", (e) => { const r = canvas.getBoundingClientRect(); mouse.x = e.clientX - r.left; mouse.y = e.clientY - r.top; }, { passive: true });
      document.addEventListener("pointerleave", () => { mouse.x = mouse.y = -9999; });
    }
  }

  /* ---------- Browser mockup tabs ---------- */
  $$("[data-browser]").forEach((wrap) => {
    const tabs = $$("[data-btab]", wrap), demos = $$("[data-demo]", wrap), url = $("[data-url]", wrap);
    const urls = ["yourbusiness.com", "yourstore.in", "launch.yourbrand.com"];
    let idx = 0, timer = 0, paused = false;
    const show = (i) => {
      idx = i;
      tabs.forEach((t, k) => { t.classList.toggle("is-active", k === i); t.setAttribute("aria-selected", String(k === i)); });
      demos.forEach((d, k) => d.classList.toggle("is-active", k === i));
      if (url) url.textContent = urls[i] || urls[0];
    };
    tabs.forEach((t, k) => t.addEventListener("click", () => { show(k); paused = true; }));
    if (!reduce) timer = setInterval(() => { if (!paused && !document.hidden) show((idx + 1) % demos.length); }, 3800);
    wrap.addEventListener("pointerenter", () => (paused = true));
    wrap.addEventListener("pointerleave", () => (paused = false));
  });

  /* ---------- Support chat animation ---------- */
  $$("[data-chat]").forEach((chat) => {
    const msgs = $$(".msg", chat), typing = $(".typing", chat);
    if (reduce) { msgs.forEach((m) => m.classList.add("show")); return; }
    let started = false;
    const play = () => {
      msgs.forEach((m) => m.classList.remove("show"));
      let t = 300;
      msgs.forEach((m, i) => {
        setTimeout(() => typing && typing.classList.add("show"), t);
        t += 900;
        setTimeout(() => { typing && typing.classList.remove("show"); m.classList.add("show"); }, t);
        t += i % 2 ? 1300 : 900;
      });
      setTimeout(play, t + 4000);
    };
    new IntersectionObserver(([en], obs) => { if (en.isIntersecting && !started) { started = true; play(); obs.disconnect(); } }, { threshold: 0.3 }).observe(chat);
  });

  /* ---------- HRMS mockup interactions ---------- */
  $$("[data-leave]").forEach((row) => {
    $$("[data-act]", row).forEach((b) =>
      b.addEventListener("click", () => {
        const act = b.dataset.act;
        $(".acts", row).outerHTML = `<span class="status ${act}">${act === "approved" ? "Approved" : "Rejected"}</span>`;
      })
    );
  });
  $$("[data-hr-nav]").forEach((b, _, all) => b.addEventListener("click", () => { all.forEach((x) => x.classList.remove("is-on")); b.classList.add("is-on"); }));

  /* ---------- Contact form ---------- */
  const form = $("[data-contact-form]");
  if (form) {
    const started = form.querySelector('[name="startedAt"]');
    started.value = String(Date.now());
    // Preselect service from ?service=slug
    try {
      const slug = new URLSearchParams(location.search).get("service");
      const map = JSON.parse(form.dataset.slugs || "{}");
      if (slug && map[slug]) form.service.value = map[slug];
    } catch (e) {}

    const okBox = $("[data-alert-success]", form), errBox = $("[data-alert-error]", form), errText = $("[data-error-text]", form);
    const btnEl = form.querySelector('button[type="submit"]'), label = $("[data-label]", btnEl);
    const emailRe = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
    const phoneRe = /^[+()\-\s\d]{7,20}$/;
    const rules = {
      fullName: (v) => v.trim().length >= 2,
      phone: (v) => phoneRe.test(v.trim()) && v.replace(/\D/g, "").length >= 7,
      email: (v) => emailRe.test(v.trim()),
      message: (v) => v.trim().length >= 10,
    };
    const check = (name) => {
      const input = form.elements[name];
      const ok = rules[name](input.value);
      const field = input.closest(".field");
      field.classList.toggle("has-error", !ok);
      input.setAttribute("aria-invalid", String(!ok));
      const err = $(".err", field);
      if (err) input.setAttribute("aria-describedby", err.id);
      return ok;
    };
    Object.keys(rules).forEach((n) => {
      const input = form.elements[n];
      input.addEventListener("blur", () => { if (input.value) check(n); });
      input.addEventListener("input", () => { if (input.closest(".field").classList.contains("has-error")) check(n); });
    });

    form.addEventListener("submit", async (e) => {
      e.preventDefault();
      okBox.classList.remove("show"); errBox.classList.remove("show");
      const results = Object.keys(rules).map(check);
      if (results.includes(false)) {
        const first = form.querySelector(".has-error .input");
        if (first) first.focus();
        return;
      }
      const data = Object.fromEntries(new FormData(form).entries());
      data.startedAt = Number(data.startedAt) || 0;
      btnEl.disabled = true; btnEl.classList.add("is-loading"); label.textContent = "Sending…";
      try {
        const controller = new AbortController();
        const to = setTimeout(() => controller.abort(), 20000);
        const res = await fetch(form.action, {
          method: "POST",
          headers: { "Content-Type": "application/json", Accept: "application/json" },
          body: JSON.stringify(data),
          signal: controller.signal,
        });
        clearTimeout(to);
        let json = {};
        try { json = await res.json(); } catch (_) {}
        if (res.ok && json.ok) {
          form.reset();
          started.value = String(Date.now());
          $$(".field", form).forEach((f) => f.classList.remove("has-error"));
          okBox.classList.add("show");
          okBox.scrollIntoView({ block: "nearest", behavior: reduce ? "auto" : "smooth" });
        } else {
          if (json.fields) Object.keys(json.fields).forEach((n) => { const f = form.elements[n] && form.elements[n].closest(".field"); if (f) f.classList.add("has-error"); });
          errText.textContent = json.error || "Something went wrong on our side. Please try again in a moment.";
          errBox.classList.add("show");
        }
      } catch (err) {
        errText.textContent = err && err.name === "AbortError" ? "The request timed out. Please check your connection and try again." : "We couldn't reach the server. Please check your connection and try again.";
        errBox.classList.add("show");
      } finally {
        btnEl.disabled = false; btnEl.classList.remove("is-loading"); label.textContent = "Send Inquiry";
      }
    });
  }
})();
