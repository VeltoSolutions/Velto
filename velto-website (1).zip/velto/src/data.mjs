// Central content + configuration for the Velto website.
// Edit contact details, social links and service copy here — every page reads from this file.

export const site = {
  name: "Velto",
  url: "https://velto.co.in",
  displayUrl: "www.velto.co.in",
  tagline: "Technology That Moves Business Forward.",
  altTagline: "Smart Solutions. Limitless Possibilities.",
  description:
    "Velto is a technology and business solutions company offering website and app development, custom software, BPO services, Excel automation, HRMS software and IT support for businesses of every size.",
  phone: "+91 98889 88510",
  phoneHref: "tel:+919888988510",
  email: "connectrm96@gmail.com",
  emailHref: "mailto:connectrm96@gmail.com",
  whatsappHref:
    "https://wa.me/919888988510?text=" + encodeURIComponent("Hi Velto, I'd like to discuss a project."),
  // Paste your real profile URLs here once the pages exist.
  // Empty values render as tidy "coming soon" placeholders (no fake links).
  social: {
    linkedin: "",
    instagram: "",
    facebook: "",
  },
  year: 2026,
};

export const nav = [
  { label: "Home", href: "/" },
  { label: "About Us", href: "/about/" },
  { label: "Services", href: "/services/", mega: true },
  { label: "Solutions", href: "/solutions/" },
  { label: "Contact Us", href: "/contact/" },
];

// Services. `dedicated: true` pages have hand-built layouts in src/pages;
// the rest use the shared service-detail template.
export const services = [
  {
    slug: "technology-solutions",
    title: "Technology Solutions",
    short: "Technology Solutions",
    icon: "cpu",
    hue: "cyan",
    summary:
      "Right-sized technology strategy, setup and integration that turns scattered tools into connected, efficient systems.",
    intro:
      "Most businesses don't need more software — they need the software they already pay for to work together. Velto assesses how your business runs today, recommends the right tools for your size and budget, and implements them so information flows without copy-paste, duplicate entry or guesswork.",
    features: [
      "Technology assessment & roadmap",
      "Cloud workspace setup & migration",
      "System integration & APIs",
      "Workflow automation",
    ],
    benefits: ["Lower operational overhead", "Systems that share data", "Decisions backed by real numbers"],
    deliverables: [
      ["Technology audit", "A clear review of the tools, data and processes you use today, with practical recommendations."],
      ["Cloud workspaces", "Google Workspace or Microsoft 365 set up properly — domains, mailboxes, shared drives and permissions."],
      ["Integrations", "Connect your website, CRM, accounting, spreadsheets and messaging so data moves automatically."],
      ["Automation", "Repetitive tasks such as reminders, report generation and data entry handled by reliable workflows."],
      ["Backup & security baselines", "Sensible backups, access control and account security for peace of mind."],
      ["Vendor & tool selection", "Unbiased guidance on which tools fit your needs — and which ones you can retire."],
    ],
    cta: "Plan Your Technology",
    seoTitle: "Technology Solutions & Business Automation",
    seoDescription:
      "Business automation solutions, cloud setup, system integration and technology roadmaps from Velto — practical IT solutions for small and growing businesses.",
  },
  {
    slug: "web-development",
    title: "Website Development",
    short: "Web Development",
    icon: "globe",
    hue: "blue",
    dedicated: true,
    summary:
      "Fast, responsive, search-friendly websites and web applications designed to turn visitors into customers.",
    features: ["Business & corporate websites", "E-commerce stores", "Custom web applications", "SEO-ready, responsive builds"],
    benefits: ["A stronger first impression", "More qualified enquiries", "A site that grows with you"],
    cta: "Build Your Website",
    seoTitle: "Website Development Company",
    seoDescription:
      "Velto is a website development company building fast, responsive, SEO-friendly business websites, e-commerce stores, landing pages and custom web applications.",
  },
  {
    slug: "app-development",
    title: "Mobile Application Development",
    short: "App Development",
    icon: "phone",
    hue: "violet",
    dedicated: true,
    summary:
      "Android, iOS and cross-platform apps built for performance, usability and measurable business outcomes.",
    features: ["Android & iOS apps", "Cross-platform development", "API integrations", "Maintenance & updates"],
    benefits: ["Reach customers on their phones", "Streamline field and team work", "A scalable mobile foundation"],
    cta: "Build Your App",
    seoTitle: "App Development Services — Android, iOS & Cross-Platform",
    seoDescription:
      "App development services from Velto: Android, iOS and cross-platform business apps, e-commerce apps, API integrations and ongoing app maintenance.",
  },
  {
    slug: "custom-software",
    title: "Custom Software Development",
    short: "Custom Software",
    icon: "code",
    hue: "blue",
    summary:
      "Software shaped around the way your business actually works — not the other way around.",
    intro:
      "Off-the-shelf software forces compromises: features you never use, gaps you patch with spreadsheets, and licence costs that grow with every new hire. Velto designs and builds custom software around your real workflow, so your team works faster and your business owns the system it runs on.",
    features: ["Requirements & solution design", "Internal tools & portals", "CRM, ERP & workflow systems", "Integrations & data migration"],
    benefits: ["Eliminate workarounds", "Own your workflow", "Scale without per-seat surprises"],
    deliverables: [
      ["Discovery & solution design", "We map your workflow, users and data before writing a line of code."],
      ["Web-based business systems", "Secure browser-based tools your team can use from office, home or the field."],
      ["CRM & sales systems", "Track leads, follow-ups, quotations and customers in one place built for your sales process."],
      ["Operations & ERP modules", "Orders, inventory, purchasing, dispatch and billing — connected and accurate."],
      ["Client & vendor portals", "Give customers and partners secure self-service access to the information they need."],
      ["Data migration", "Move records from spreadsheets or legacy tools safely, with validation at every step."],
    ],
    cta: "Discuss Your Software",
    seoTitle: "Custom Software Development",
    seoDescription:
      "Custom software development by Velto — CRM, ERP modules, internal tools, portals and integrations designed around how your business actually works.",
  },
  {
    slug: "bpo",
    title: "Business Process Outsourcing (BPO)",
    short: "BPO Solutions",
    icon: "headset",
    hue: "cyan",
    dedicated: true,
    summary:
      "Reliable customer support and back-office operations that free your team to focus on growth.",
    features: ["Voice, email & chat support", "Back-office & data management", "Quality assurance", "Reporting & performance management"],
    benefits: ["Lower operating costs", "Consistent customer experience", "Capacity that flexes with demand"],
    cta: "Optimize Your Operations",
    seoTitle: "BPO Services — Customer Support & Back-Office Operations",
    seoDescription:
      "BPO services from Velto: voice, email and chat customer support, back-office operations, data management, quality assurance and process optimization.",
  },
  {
    slug: "excel-automation",
    title: "Excel Automation & Business Computing Tools",
    short: "Excel Automation",
    icon: "sheet",
    hue: "green",
    dedicated: true,
    summary:
      "Custom Excel and Google Sheets tools — dashboards, MIS reports, calculators and trackers — that save hours every week.",
    features: ["Advanced dashboards & MIS", "Automated reports", "Attendance, payroll & inventory tools", "Google Sheets automation"],
    benefits: ["Hours saved every week", "Fewer manual errors", "Clear, instant visibility"],
    cta: "Automate Your Business",
    seoTitle: "Excel Automation, Dashboards & MIS Reporting",
    seoDescription:
      "Excel automation and Google Sheets automation by Velto: dashboards, MIS reports, attendance and payroll tools, inventory and sales trackers, and custom business calculators.",
  },
  {
    slug: "hrms",
    title: "HRMS & HR Automation Solutions",
    short: "HRMS Solutions",
    icon: "users",
    hue: "violet",
    dedicated: true,
    summary:
      "A customizable HRMS for attendance, leave, payroll, recruitment, performance and employee self-service.",
    features: ["Attendance & leave", "Payroll management", "Recruitment & onboarding", "Self-service & analytics"],
    benefits: ["Less HR admin", "Accurate, on-time payroll", "A better employee experience"],
    cta: "Get Your Custom HRMS",
    seoTitle: "HRMS Software — Custom HR Automation",
    seoDescription:
      "Customizable HRMS software by Velto with attendance, leave, payroll, recruitment, onboarding, performance, self-service portal and HR analytics — tailored to your company size.",
  },
  {
    slug: "business-consulting",
    title: "Business Process Consulting",
    short: "Process Consulting",
    icon: "workflow",
    hue: "amber",
    summary:
      "Process mapping, optimization and practical recommendations to make operations faster, leaner and easier to manage.",
    intro:
      "Growth exposes every inefficiency: approvals that wait on one person, reports rebuilt by hand each month, and handovers that lose information. Velto maps how work really flows through your business, finds the bottlenecks, and designs simpler processes — with technology only where it genuinely helps.",
    features: ["Process mapping & audit", "SOP design & documentation", "KPI & reporting frameworks", "Automation opportunity analysis"],
    benefits: ["Clarity across teams", "Fewer bottlenecks", "Improvements you can measure"],
    deliverables: [
      ["Process discovery", "Interviews and walkthroughs that capture how work actually happens, not how it's supposed to."],
      ["Process maps", "Clear visual maps of each workflow, owners, hand-offs and decision points."],
      ["Bottleneck analysis", "Where time, money and quality are lost — ranked by impact and effort to fix."],
      ["SOPs & playbooks", "Step-by-step standard operating procedures your team can follow and train with."],
      ["KPI frameworks", "The handful of metrics that matter, how to measure them and who owns them."],
      ["Automation roadmap", "Which steps to automate first, with realistic effort and cost estimates."],
    ],
    cta: "Improve Your Processes",
    seoTitle: "Business Process Consulting & Optimization",
    seoDescription:
      "Business process consulting from Velto: process mapping, SOP design, KPI frameworks and automation roadmaps that make operations leaner and easier to manage.",
  },
  {
    slug: "it-support",
    title: "IT Support & Digital Transformation",
    short: "IT Support",
    icon: "server",
    hue: "blue",
    summary:
      "Dependable IT support and a practical path to modernize your systems, tools and ways of working.",
    intro:
      "When technology fails, work stops. Velto provides responsive IT support for everyday issues and helps you modernize step by step — moving files to the cloud, standardizing devices and accounts, and introducing tools that make your team more productive.",
    features: ["Remote IT helpdesk", "Device, network & email setup", "Cloud & collaboration tools", "Digital transformation roadmap"],
    benefits: ["Less downtime", "Secure, organized IT", "A team ready for modern tools"],
    deliverables: [
      ["Remote helpdesk", "Fast help for software issues, email problems, printers, access and everyday IT questions."],
      ["Device & network setup", "Laptops, desktops, Wi-Fi and office networks configured correctly and securely."],
      ["Email & domain management", "Professional email on your domain, DNS, spam protection and mailbox administration."],
      ["Cloud migration", "Move files and workflows from local drives to secure, shareable cloud storage."],
      ["Security essentials", "Multi-factor authentication, password policies, backups and access reviews."],
      ["Transformation roadmap", "A phased plan to digitize paper-based and manual processes across your business."],
    ],
    cta: "Get IT Support",
    seoTitle: "IT Support & Digital Transformation Services",
    seoDescription:
      "IT support and digital transformation for small businesses: remote helpdesk, device and email setup, cloud migration, security essentials and modernization roadmaps.",
  },
];

export const serviceHref = (slug) => `/services/${slug}/`;
export const getService = (slug) => services.find((s) => s.slug === slug);

export const serviceOptions = [...services.map((s) => s.title), "Other / Not sure yet"];

export const budgetOptions = [
  "Under ₹50,000",
  "₹50,000 – ₹1,50,000",
  "₹1,50,000 – ₹5,00,000",
  "Above ₹5,00,000",
  "Not sure yet",
];

export const industries = [
  ["bag", "Retail & E-commerce"],
  ["heart", "Healthcare & Clinics"],
  ["cap", "Education & Training"],
  ["factory", "Manufacturing"],
  ["building", "Real Estate & Construction"],
  ["truck", "Logistics & Distribution"],
  ["bank", "Finance & Accounting"],
  ["cup", "Hospitality & Food"],
  ["briefcase", "Professional Services"],
  ["rocket", "Startups"],
];

export const processSteps = [
  ["Discover", "We listen first — your goals, users, constraints and budget — and agree on what success looks like."],
  ["Design", "We plan the solution, map the workflow and show you designs before development begins."],
  ["Build", "We develop in short, visible milestones so you see progress and give feedback early."],
  ["Launch", "We test thoroughly, deploy carefully and train your team so the rollout is smooth."],
  ["Support", "We stay with you — maintenance, improvements and help whenever you need it."],
];
