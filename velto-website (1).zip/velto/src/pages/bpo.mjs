import { icon } from "../icons.mjs";
import { ico } from "../layout.mjs";
import { sectionHead, pageHero, btn, ctaSection, offerGrid, supportConsole, relatedServices } from "../components.mjs";
import { getService } from "../data.mjs";

const s = getService("bpo");

export default {
  path: "/services/bpo/",
  title: s.seoTitle,
  description: s.seoDescription,
  service: s,
  body: () => `
${pageHero({
  crumbs: [["Services", "/services/"], ["BPO Solutions"]],
  eyebrow: "BPO & Business Process Solutions",
  title: "Your operations, {running smoother.}",
  lead: "Velto is your business process and operational support partner. We handle customer conversations and back-office work with care, consistency and clear reporting — so your team can focus on growth.",
  actions: btn("Optimize Your Operations", "/contact/?service=bpo", "primary", "data-magnetic") + `<a class="btn btn-ghost" href="#services">What we handle</a>`,
  visual: supportConsole(),
})}

<section class="section" id="services" style="scroll-margin-top:90px">
  <div class="container">
    ${sectionHead({ eyebrow: "What we handle", title: "Front office to back office, {covered.}", lead: "Pick the processes you want to outsource. We'll build the team, train them on your business and run to agreed quality standards." })}
    ${offerGrid(
      [
        ["headset", "Customer support", "Courteous, well-trained agents who represent your brand and resolve issues quickly."],
        ["mail", "Email support", "Organized inbox management with templated, personalised replies and tracked turnaround."],
        ["message", "Chat support", "Real-time website and messaging support that converts questions into customers."],
        ["call", "Voice support", "Inbound helplines and outbound calling for follow-ups, confirmations and feedback."],
        ["file", "Back-office operations", "Order processing, invoicing support, document handling and administrative tasks."],
        ["database", "Data management", "Data entry, cleansing, validation, migration and record maintenance at scale."],
        ["checkCircle", "Quality assurance", "Call and ticket audits, scorecards and coaching to keep standards consistently high."],
        ["workflow", "Process optimization", "We streamline workflows as we run them — removing steps that don't add value."],
        ["bars", "Reporting & performance", "Clear dashboards on volumes, response times, resolution and quality — shared regularly."],
        ["compass", "Operational consulting", "Advice on staffing, SOPs, tools and metrics to make your operation scalable."],
      ],
      "cyan"
    )}
  </div>
</section>

<section class="section surface">
  <div class="container">
    <div class="split" style="align-items:start">
      ${sectionHead({ eyebrow: "Operating model", title: "A structured approach {to outsourcing.}", lead: "Outsourcing works when expectations are clear and performance is visible. Here's how we set up every process." })}
      <div>
        ${[
          ["Understand", "We document your process, tone of voice, tools, escalation paths and success metrics."],
          ["Set up & train", "We prepare SOPs and knowledge bases, then train the team on your products and customers."],
          ["Operate", "Day-to-day delivery with supervisors, defined service levels and quality checks."],
          ["Measure", "Regular performance reports covering volume, speed, quality and customer feedback."],
          ["Improve", "Continuous refinement — automating repetitive steps and fixing root causes."],
        ]
          .map(([t, d], i) => `<div class="principle" data-reveal style="--d:${i * 0.05}s"><span class="n">0${i + 1}</span><div><h3>${t}</h3><p>${d}</p></div></div>`)
          .join("")}
      </div>
    </div>
  </div>
</section>

<section class="section">
  <div class="container">
    ${sectionHead({ eyebrow: "Benefits", title: "Why businesses {outsource with Velto.}", center: true })}
    <div class="grid g-4 mt-l">
      ${[
        ["wallet", "green", "Lower costs", "Reduce hiring, training and infrastructure overheads."],
        ["refresh", "cyan", "Flexible capacity", "Scale up for peaks and campaigns, scale down when it's quiet."],
        ["smile", "violet", "Better experiences", "Consistent, friendly service that customers remember."],
        ["chart", "blue", "Full visibility", "Transparent reporting on every process we run."],
      ]
        .map(([ic, hue, t, d], i) => `<div class="card" data-reveal style="--d:${i * 0.06}s" data-spotlight>${ico(ic, hue)}<h3 class="h4">${t}</h3><p>${d}</p></div>`)
        .join("")}
    </div>
  </div>
</section>

${relatedServices("bpo")}
${ctaSection({ eyebrow: "BPO & operations", title: "Optimize your {operations.}", primary: "Optimize Your Operations", href: "/contact/?service=bpo" })}
`,
};
