import { industries, serviceHref, getService } from "../data.mjs";
import { icon } from "../icons.mjs";
import { ico, esc } from "../layout.mjs";
import { sectionHead, pageHero, btn, ctaSection } from "../components.mjs";

const stages = [
  {
    ic: "rocket", hue: "cyan", name: "Launch", who: "For startups & new ventures",
    desc: "Everything you need to look professional and start operating from day one.",
    includes: ["web-development", "technology-solutions", "app-development"],
    points: ["Brand-ready website or landing page", "Business email & cloud workspace", "Optional MVP mobile or web app"],
  },
  {
    ic: "zap", hue: "blue", name: "Automate", who: "For small & growing businesses",
    desc: "Remove manual work, organise people processes and get real-time visibility.",
    includes: ["excel-automation", "hrms", "it-support"],
    points: ["Dashboards, MIS and automated reports", "HRMS for attendance, leave & payroll", "Reliable IT support"],
    featured: true,
  },
  {
    ic: "layers", hue: "violet", name: "Scale", who: "For established companies",
    desc: "Connect systems, streamline operations and extend capacity without adding overhead.",
    includes: ["custom-software", "bpo", "business-consulting"],
    points: ["Custom software & integrations", "Outsourced support & back office", "Process consulting & roadmaps"],
  },
];

const needs = [
  ["globe", "cyan", "Get found and win customers online", "A fast, SEO-friendly website or online store that converts visitors.", "web-development"],
  ["phone", "violet", "Reach customers on mobile", "Android, iOS or cross-platform apps for customers or your field team.", "app-development"],
  ["sheet", "green", "Stop wasting hours on spreadsheets", "Automated Excel and Google Sheets tools, dashboards and reports.", "excel-automation"],
  ["users", "violet", "Manage people and payroll", "A customizable HRMS for attendance, leave, payroll and more.", "hrms"],
  ["headset", "cyan", "Handle more customers without hiring", "Voice, email and chat support plus back-office operations.", "bpo"],
  ["code", "blue", "Replace workarounds with a real system", "Custom software designed around how your business works.", "custom-software"],
  ["workflow", "amber", "Fix slow, messy processes", "Process mapping, SOPs and an automation roadmap.", "business-consulting"],
  ["server", "blue", "Modernize everyday IT", "Helpdesk, cloud migration, security and device management.", "it-support"],
];

export default {
  path: "/solutions/",
  title: "Business Solutions for Startups, SMEs & Enterprises",
  description:
    "Velto solutions by business stage and need: launch, automate and scale with websites, apps, Excel automation, HRMS, BPO, custom software and IT solutions for small businesses.",
  body: () => `
${pageHero({
  crumbs: [["Solutions"]],
  eyebrow: "Solutions",
  title: "The right solution for {where you are today.}",
  lead: "Whether you're launching, streamlining or scaling, Velto combines the right services into one coordinated solution — so you get outcomes, not just deliverables.",
  actions: btn("Find Your Solution", "/contact/", "primary", "data-magnetic") + `<a class="btn btn-ghost" href="#by-need">Browse by need</a>`,
  center: true,
})}

<section class="section-sm">
  <div class="container">
    ${sectionHead({ eyebrow: "By business stage", title: "Launch. Automate. {Scale.}", center: true })}
    <div class="grid g-3 mt-l">
      ${stages
        .map(
          (st, i) => `<div class="card lift" data-reveal style="--d:${i * 0.08}s;${st.featured ? "border-color:rgba(91,140,255,.45);background:linear-gradient(180deg,rgba(47,107,255,.12),rgba(255,255,255,.015))" : ""}" data-spotlight>
        <div style="display:flex;justify-content:space-between;align-items:start">${ico(st.ic, st.hue, "lg")}${st.featured ? '<span class="tag" style="color:#c7d6ff;border-color:rgba(91,140,255,.4)">Most requested</span>' : ""}</div>
        <h3 class="h2" style="font-size:2rem">${st.name}</h3>
        <p class="small" style="color:var(--blue-2);margin-top:6px">${st.who}</p>
        <p>${st.desc}</p>
        <ul class="check-list">${st.points.map((p) => `<li>${icon("check")}${p}</li>`).join("")}</ul>
        <div class="tags mt-m">${st.includes.map((slug) => `<a class="tag" href="${serviceHref(slug)}">${esc(getService(slug).short)}</a>`).join("")}</div>
        <div class="mt-m"><a class="btn btn-${st.featured ? "primary" : "ghost"} btn-sm btn-block" href="/contact/">Plan my ${st.name.toLowerCase()} solution${st.featured ? " " + icon("arrowRight", "icon icon-arrow") : ""}</a></div>
      </div>`
        )
        .join("")}
    </div>
  </div>
</section>

<section class="section" id="by-need" style="scroll-margin-top:90px">
  <div class="container">
    ${sectionHead({ eyebrow: "By business need", title: "Start with the problem {you want solved.}" })}
    <div class="grid g-2 mt-l">
      ${needs
        .map(
          ([ic, hue, t, d, slug], i) => `<a class="card lift offer" href="${serviceHref(slug)}" data-reveal style="--d:${(i % 2) * 0.07}s" data-spotlight>${ico(ic, hue)}<div style="flex:1"><h3>${t}</h3><p>${d}</p></div><span class="link-arrow" style="align-self:center">${icon("arrowRight")}</span></a>`
        )
        .join("")}
    </div>
  </div>
</section>

<section class="section surface">
  <div class="container">
    ${sectionHead({ eyebrow: "By industry", title: "Solutions shaped by {industry know-how.}", lead: "We adapt every solution to the workflows, compliance needs and customer expectations of your sector.", center: true })}
    <div class="industries mt-l">${industries.map(([ic, t], i) => `<div class="industry" data-reveal style="--d:${(i % 5) * 0.05}s">${icon(ic)}<strong>${t}</strong></div>`).join("")}</div>
  </div>
</section>

${ctaSection({ title: "Let's design {your solution.}", lead: "Tell us your goals and challenges. We'll put together a practical plan with clear priorities, timelines and costs." })}
`,
};
