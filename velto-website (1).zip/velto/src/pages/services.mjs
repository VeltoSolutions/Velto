import { services, serviceHref } from "../data.mjs";
import { icon } from "../icons.mjs";
import { ico, esc } from "../layout.mjs";
import { pageHero, btn, ctaSection, processSection } from "../components.mjs";

export default {
  path: "/services/",
  title: "Services — Web, App & Software Development, BPO, Excel Automation, HRMS",
  description:
    "Explore Velto's services: website development, app development, custom software, BPO services, Excel automation, HRMS software, business process consulting and IT support for small businesses.",
  body: () => `
${pageHero({
  crumbs: [["Services"]],
  eyebrow: "9 service lines · one partner",
  title: "Solutions that build, automate {and run your business.}",
  lead: "Choose a single service or combine several. Every engagement is scoped to your goals, workflow and budget — and backed by support after launch.",
  actions: btn("Discuss Your Requirements", "/contact/", "primary", "data-magnetic") + `<a class="btn btn-ghost" href="#all-services">Browse services</a>`,
})}

<section class="section-sm" id="all-services" style="scroll-margin-top:90px">
  <div class="container">
    ${services
      .map(
        (s, i) => `<article class="card svc-row" data-reveal data-spotlight id="${s.slug}">
      <div>
        <div style="display:flex;align-items:center;gap:16px">${ico(s.icon, s.hue, "lg")}<span class="svc-num">${String(i + 1).padStart(2, "0")} / 09</span></div>
        <h2>${esc(s.title)}</h2>
        <p class="lead">${esc(s.summary)}</p>
        <div class="btn-row">
          <a class="btn btn-primary btn-sm" href="/contact/?service=${s.slug}">${esc(s.cta)} ${icon("arrowRight", "icon icon-arrow")}</a>
          <a class="btn btn-ghost btn-sm" href="${serviceHref(s.slug)}">View details</a>
        </div>
      </div>
      <div class="svc-cols">
        <div><h4>Key features</h4><ul class="check-list">${s.features.map((f) => `<li>${icon("check")}${esc(f)}</li>`).join("")}</ul></div>
        <div><h4>Business benefits</h4><div class="tags">${s.benefits.map((b) => `<span class="tag benefit">${icon("arrowUpRight")}${esc(b)}</span>`).join("")}</div></div>
      </div>
    </article>`
      )
      .join("")}
  </div>
</section>

${processSection({ title: "How every engagement {comes together.}" })}

${ctaSection({ title: "Not sure which service {you need?}", lead: "Tell us about the problem you're trying to solve. We'll recommend the simplest, most cost-effective way forward." })}
`,
};
