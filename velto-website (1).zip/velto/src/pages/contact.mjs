import { site, serviceOptions, budgetOptions, services } from "../data.mjs";
import { icon, whatsapp } from "../icons.mjs";
import { ico, esc } from "../layout.mjs";
import { pageHero } from "../components.mjs";

const slugMap = Object.fromEntries(services.map((s) => [s.slug, s.title]));

export default {
  path: "/contact/",
  title: "Contact Velto — Get a Quote",
  description:
    "Contact Velto for website development, app development, custom software, BPO services, Excel automation or HRMS software. Call +91 98889 88510, email or send an inquiry.",
  body: () => `
${pageHero({
  crumbs: [["Contact Us"]],
  eyebrow: "Contact Us",
  title: "Let's start {a conversation.}",
  lead: "Tell us about your business and what you'd like to achieve. We'll get back to you with practical recommendations and a clear, no-obligation estimate.",
})}

<section class="section-sm" style="padding-top:0">
  <div class="container">
    <div class="contact-grid">
      <div>
        <div class="contact-cards">
          <a class="card c-card" href="${site.phoneHref}" data-reveal data-spotlight>${ico("call", "cyan")}<div><small>Call us</small><strong>${site.phone}</strong></div><span class="arrow">${icon("arrowRight")}</span></a>
          <a class="card c-card" href="${site.emailHref}" data-reveal style="--d:.06s" data-spotlight>${ico("mail", "blue")}<div><small>Email us</small><strong>${site.email}</strong></div><span class="arrow">${icon("arrowRight")}</span></a>
          <a class="card c-card wa" href="${site.whatsappHref}" target="_blank" rel="noopener" data-reveal style="--d:.12s" data-spotlight><span class="ico">${whatsapp()}</span><div><small>WhatsApp</small><strong>Chat with us instantly</strong></div><span class="arrow">${icon("arrowRight")}</span></a>
          <a class="card c-card" href="${site.url}" data-reveal style="--d:.18s" data-spotlight>${ico("globe", "violet")}<div><small>Website</small><strong>${site.displayUrl}</strong></div><span class="arrow">${icon("arrowRight")}</span></a>
        </div>
        <div class="card mt-m" data-reveal style="padding:28px">
          <h3 class="h4">What happens next?</h3>
          <ol class="next-steps mt-m">
            <li><b>1</b><div><strong>We review your inquiry</strong>Your details reach our team directly by email.</div></li>
            <li><b>2</b><div><strong>We get in touch</strong>We'll call or email to understand your requirements.</div></li>
            <li><b>3</b><div><strong>You receive a proposal</strong>A clear scope, timeline and estimate — no obligation.</div></li>
          </ol>
        </div>
      </div>

      <div class="card form-card" data-reveal="scale">
        <h2 class="h3">Send us an inquiry</h2>
        <p class="mt-s">Fields marked <span style="color:var(--cyan)">*</span> are required.</p>
        <form class="mt-m" id="contact-form" action="/api/contact" method="post" novalidate data-contact-form data-slugs='${esc(JSON.stringify(slugMap))}'>
          <div class="form-grid">
            <div class="field"><label for="f-name">Full Name <span class="req">*</span></label><input class="input" id="f-name" name="fullName" type="text" autocomplete="name" required minlength="2" maxlength="100" placeholder="Your full name"><p class="err" id="e-name">Please enter your full name.</p></div>
            <div class="field"><label for="f-company">Company Name <span class="opt">(optional)</span></label><input class="input" id="f-company" name="company" type="text" autocomplete="organization" maxlength="120" placeholder="Your company"></div>
            <div class="field"><label for="f-phone">Phone Number <span class="req">*</span></label><input class="input" id="f-phone" name="phone" type="tel" autocomplete="tel" inputmode="tel" required maxlength="20" placeholder="+91 98765 43210"><p class="err" id="e-phone">Please enter a valid phone number.</p></div>
            <div class="field"><label for="f-email">Email Address <span class="req">*</span></label><input class="input" id="f-email" name="email" type="email" autocomplete="email" required maxlength="160" placeholder="you@company.com"><p class="err" id="e-email">Please enter a valid email address.</p></div>
            <div class="field"><label for="f-service">Service Required</label><select class="input" id="f-service" name="service"><option value="">Select a service</option>${serviceOptions
              .map((o) => `<option>${esc(o)}</option>`)
              .join("")}</select></div>
            <div class="field"><label for="f-budget">Project Budget <span class="opt">(optional)</span></label><select class="input" id="f-budget" name="budget"><option value="">Select a range</option>${budgetOptions
              .map((o) => `<option>${esc(o)}</option>`)
              .join("")}</select></div>
            <div class="field full"><label for="f-message">Message / Requirements <span class="req">*</span></label><textarea class="input" id="f-message" name="message" required minlength="10" maxlength="5000" placeholder="Tell us about your project, goals and timeline…"></textarea><p class="err" id="e-message">Please describe your requirements (at least 10 characters).</p></div>
          </div>
          <div class="hp" aria-hidden="true"><label for="f-website">Leave this field empty</label><input id="f-website" name="website" type="text" tabindex="-1" autocomplete="off"></div>
          <input type="hidden" name="startedAt" value="">
          <div class="form-foot">
            <p>By submitting, you agree that Velto may contact you about your inquiry. See our <a href="/privacy/" style="text-decoration:underline">Privacy Policy</a>.</p>
            <button class="btn btn-primary" type="submit" data-magnetic><span class="spinner" aria-hidden="true"></span><span data-label>Send Inquiry</span> ${icon("arrowRight", "icon icon-arrow")}</button>
          </div>
          <div class="form-alert success" role="status" aria-live="polite" data-alert-success>${icon("checkCircle")}<div><strong>Thank you — your inquiry has been sent.</strong><br>We've received your details and will get back to you shortly. For anything urgent, call <a href="${site.phoneHref}">${site.phone}</a>.</div></div>
          <div class="form-alert error" role="alert" aria-live="assertive" data-alert-error>${icon("close")}<div><strong>Sorry, your inquiry couldn't be sent.</strong><br><span data-error-text>Please try again in a moment.</span> You can also reach us at <a href="${site.emailHref}">${site.email}</a> or <a href="${site.whatsappHref}" target="_blank" rel="noopener">WhatsApp</a>.</div></div>
        </form>
      </div>
    </div>
  </div>
</section>
`,
};
