import { icon } from "../icons.mjs";
import { ico, esc } from "../layout.mjs";
import { sectionHead, pageHero, btn, ctaSection, processSection, relatedServices } from "../components.mjs";

const deliverableIcons = ["search", "layers", "link", "zap", "shield", "compass"];

// Visual: a glass "control panel" summarising the service, generated from its data
const panel = (s) => `<div class="mock-wrap"><div class="mock-glow"></div><div class="mock svc-panel" data-reveal="scale">
  <div class="browser-chrome"><div class="dots"><i></i><i></i><i></i></div><div class="url">${icon(s.icon)}<span>velto · ${esc(s.short.toLowerCase())}</span></div></div>
  <div class="svc-panel-body">
    <div class="svc-panel-hero">${ico(s.icon, s.hue, "lg")}<div><strong>${esc(s.title)}</strong><small>${esc(s.features.length)} core capabilities · tailored delivery</small></div></div>
    <div class="svc-panel-grid">${s.features
      .map((f, i) => `<div class="svc-panel-item" style="--d:${i * 0.12}s"><span class="pi">${icon("checkCircle")}</span><span>${esc(f)}</span><span class="pb"><i style="--w:${[92, 78, 86, 70][i]}%"></i></span></div>`)
      .join("")}</div>
  </div>
</div></div>`;

export function servicePage(s) {
  return {
    path: `/services/${s.slug}/`,
    title: s.seoTitle,
    description: s.seoDescription,
    service: s,
    body: () => `
${pageHero({
  crumbs: [["Services", "/services/"], [s.short]],
  eyebrow: s.title,
  title: headline(s),
  lead: esc(s.intro),
  actions: btn(s.cta, `/contact/?service=${s.slug}`, "primary", "data-magnetic") + `<a class="btn btn-ghost" href="#deliverables">What's included</a>`,
  visual: panel(s),
})}

<section class="section" id="deliverables" style="scroll-margin-top:90px">
  <div class="container">
    ${sectionHead({ eyebrow: "What's included", title: "What we {deliver.}" })}
    <div class="grid g-3 mt-l">${s.deliverables
      .map(
        ([t, d], i) =>
          `<div class="card offer" data-reveal style="--d:${(i % 3) * 0.07}s" data-spotlight>${ico(deliverableIcons[i % 6], s.hue)}<div><h3>${esc(t)}</h3><p>${esc(d)}</p></div></div>`
      )
      .join("")}</div>
  </div>
</section>

<section class="section surface">
  <div class="container">
    <div class="split">
      ${sectionHead({ eyebrow: "Business benefits", title: "The outcomes {that matter.}", lead: "Every engagement is measured by what changes in your business — not by hours or features." })}
      <div class="grid" style="gap:14px">${s.benefits
        .map(
          (b, i) =>
            `<div class="card" data-reveal style="--d:${i * 0.07}s;display:flex;align-items:center;gap:18px;padding:24px" data-spotlight>${ico("arrowUpRight", "green")}<h3 class="h4" style="margin:0">${esc(b)}</h3></div>`
        )
        .join("")}
        <div class="card" data-reveal style="--d:.25s;padding:24px"><p style="margin:0">Have a specific requirement? <a class="link-arrow" href="/contact/?service=${s.slug}">Tell us about it ${icon("arrowRight")}</a></p></div>
      </div>
    </div>
  </div>
</section>

${processSection()}
${relatedServices(s.slug)}
${ctaSection({ eyebrow: s.short, title: `${s.cta.split(" ").slice(0, -1).join(" ")} {${s.cta.split(" ").slice(-1)[0]}.}`, primary: s.cta, href: `/contact/?service=${s.slug}` })}
`,
  };
}

const headlines = {
  "technology-solutions": "Technology that works {together, for you.}",
  "custom-software": "Software built around {how you work.}",
  "business-consulting": "Simpler processes. {Stronger business.}",
  "it-support": "IT that keeps up {with your ambitions.}",
};
function headline(s) {
  return headlines[s.slug] || s.title;
}
