import { icon } from "../icons.mjs";
import { ico } from "../layout.mjs";
import { sectionHead, pageHero, btn, ctaSection, splitText } from "../components.mjs";

export default {
  path: "/about/",
  title: "About Velto — Accessible Technology for Every Business",
  description:
    "Learn about Velto: our vision, mission and philosophy, and how we make modern technology, automation and business solutions affordable and accessible for startups, small businesses and established companies.",
  body: () => `
${pageHero({
  crumbs: [["About Us"]],
  eyebrow: "About Velto",
  title: "Technology partners for {businesses of every size.}",
  lead: "Velto exists to close the gap between what modern technology can do and what most businesses can actually access. We design, build and support the digital tools that help organisations work smarter and grow faster.",
  actions: btn("Work With Us", "/contact/", "primary", "data-magnetic") + `<a class="btn btn-ghost" href="/services/">Our Services</a>`,
})}

<section class="section-sm">
  <div class="container">
    <div class="split wide-left">
      <div>
        <span class="eyebrow" data-reveal>Who we are</span>
        <p class="statement mt-m" data-scrub>We are a technology and business solutions company bringing engineering, automation and operational expertise together — so our clients get one dependable partner instead of a patchwork of vendors.</p>
      </div>
      <div data-reveal="right">
        <p class="lead">Our work spans websites, mobile apps, custom software, Excel and Google Sheets automation, HRMS, business process outsourcing, consulting and IT support. What connects all of it is a simple goal: make your business easier to run and better positioned to grow.</p>
      </div>
    </div>
  </div>
</section>

<section class="section">
  <div class="container">
    <div class="grid g-3">
      <div class="card vm-card" data-reveal data-spotlight>${ico("compass", "cyan", "lg")}<span class="eyebrow mt-m" style="display:flex">Our vision</span><p class="big">A world where every business — not just the biggest — can use modern technology to compete, serve and grow.</p></div>
      <div class="card vm-card" data-reveal style="--d:.08s" data-spotlight>${ico("target", "blue", "lg")}<span class="eyebrow mt-m" style="display:flex">Our mission</span><p class="big">To deliver reliable, affordable technology and business solutions that solve real problems and create measurable value.</p></div>
      <div class="card vm-card" data-reveal style="--d:.16s" data-spotlight>${ico("sparkles", "violet", "lg")}<span class="eyebrow mt-m" style="display:flex">Our philosophy</span><p class="big">Technology should simplify work, not complicate it. Start with the problem, keep it practical, and build to last.</p></div>
    </div>
  </div>
</section>

<section class="section surface">
  <div class="container">
    <div class="split">
      <div>
        ${sectionHead({ eyebrow: "Why Velto exists", title: "Great technology {shouldn't be a luxury.}" })}
      </div>
      <div data-reveal>
        <p class="lead">Too many businesses run on manual spreadsheets, disconnected tools and outdated websites — not because they don't want better, but because good technology has felt expensive, complicated or out of reach.</p>
        <p class="lead mt-s">Velto was founded to change that. We take the approaches used by leading technology companies and make them practical for real-world budgets, timelines and teams — with honest advice about what you need, and what you don't.</p>
      </div>
    </div>
  </div>
</section>

<section class="section">
  <div class="container">
    <div class="quote-block" data-reveal="scale">
      <span class="eyebrow">Our commitment</span>
      <p class="mt-m">Affordable and accessible technology — <span class="gradient-text">without cutting corners on quality, security or support.</span></p>
      <div class="grid g-3 mt-l">
        <div data-reveal><h3 class="h4">${icon("wallet", "icon")} Right-sized pricing</h3><p class="mt-s">Clear estimates, phased delivery and options that fit your budget today and scale tomorrow.</p></div>
        <div data-reveal style="--d:.08s"><h3 class="h4">${icon("message", "icon")} No jargon</h3><p class="mt-s">We explain choices in plain business terms so you can make confident decisions.</p></div>
        <div data-reveal style="--d:.16s"><h3 class="h4">${icon("lifebuoy", "icon")} Long-term support</h3><p class="mt-s">Launch is the beginning. We maintain, improve and support what we build.</p></div>
      </div>
    </div>
  </div>
</section>

<section class="section">
  <div class="container">
    ${sectionHead({ eyebrow: "Who we help", title: "From first idea {to established enterprise.}", lead: "Different stages need different solutions. We meet you where you are.", center: true })}
    <div class="grid g-3 mt-l">
      <div class="card lift" data-reveal data-spotlight>${ico("rocket", "cyan", "lg")}<h3 class="h3">Startups</h3><p>Launch fast with a professional website or app, the right cloud tools and simple automation — without overspending before you've found your market.</p>
        <ul class="check-list"><li>${icon("check")}MVPs and launch-ready websites</li><li>${icon("check")}Lean, scalable foundations</li><li>${icon("check")}Guidance on what to build first</li></ul></div>
      <div class="card lift" data-reveal style="--d:.08s" data-spotlight>${ico("briefcase", "blue", "lg")}<h3 class="h3">Small & growing businesses</h3><p>Replace manual work and scattered spreadsheets with dashboards, HRMS, custom tools and outsourced support that free up your team.</p>
        <ul class="check-list"><li>${icon("check")}Excel & Google Sheets automation</li><li>${icon("check")}HR, payroll and attendance systems</li><li>${icon("check")}Customer support and back office</li></ul></div>
      <div class="card lift" data-reveal style="--d:.16s" data-spotlight>${ico("building", "violet", "lg")}<h3 class="h3">Established companies</h3><p>Modernize legacy processes, integrate systems and scale operations with custom software, consulting and dedicated process teams.</p>
        <ul class="check-list"><li>${icon("check")}Custom software & integrations</li><li>${icon("check")}Process consulting & optimization</li><li>${icon("check")}Digital transformation roadmaps</li></ul></div>
    </div>
  </div>
</section>

<section class="section surface">
  <div class="container">
    <div class="split" style="align-items:start">
      ${sectionHead({ eyebrow: "How we work", title: "Innovation with purpose. {Satisfaction by design.}", lead: "Our approach to innovation and customer satisfaction rests on a few principles we don't compromise on." })}
      <div>
        ${[
          ["Problem first, technology second", "We start by understanding your goals and constraints. The right solution is sometimes simpler than you expect."],
          ["Build in visible steps", "Short milestones, regular demos and early feedback mean no surprises at the end."],
          ["Quality you can rely on", "Clean code, careful testing, security-conscious defaults and documentation you can hand over."],
          ["Measure what matters", "We define success up front — time saved, errors reduced, enquiries generated — and track it."],
          ["Partnership after launch", "Responsive support, maintenance and continuous improvement as your business evolves."],
        ]
          .map(([t, d], i) => `<div class="principle" data-reveal style="--d:${i * 0.05}s"><span class="n">0${i + 1}</span><div><h3>${t}</h3><p>${d}</p></div></div>`)
          .join("")}
      </div>
    </div>
  </div>
</section>

${ctaSection({ title: "Let's make technology {work for your business.}" })}
`,
};
