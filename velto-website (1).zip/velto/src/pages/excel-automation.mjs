import { icon } from "../icons.mjs";
import { ico } from "../layout.mjs";
import { sectionHead, pageHero, btn, ctaSection, processSection, offerGrid, excelMockup, relatedServices } from "../components.mjs";
import { getService } from "../data.mjs";

const s = getService("excel-automation");

export default {
  path: "/services/excel-automation/",
  title: s.seoTitle,
  description: s.seoDescription,
  service: s,
  body: () => `
${pageHero({
  crumbs: [["Services", "/services/"], ["Excel Automation"]],
  eyebrow: "Excel Automation & Business Tools",
  title: "Spreadsheets that {work for you.}",
  lead: "Velto turns the spreadsheets your business already depends on into smart, automated tools — dashboards that update themselves, reports generated in one click, and calculators your whole team can trust.",
  actions: btn("Automate Your Business", "/contact/?service=excel-automation", "primary", "data-magnetic") + `<a class="btn btn-ghost" href="#tools">Explore tools</a>`,
  visual: excelMockup(),
})}

<section class="section" id="tools" style="scroll-margin-top:90px">
  <div class="container">
    ${sectionHead({ eyebrow: "Custom business tools", title: "Built in Excel & Google Sheets. {Tailored to you.}", lead: "No new software to learn. We build on the tools your team already uses every day." })}
    ${offerGrid(
      [
        ["chart", "Advanced Excel dashboards", "Interactive dashboards with slicers, charts and KPIs that refresh from your raw data."],
        ["refresh", "Automated reporting systems", "Daily, weekly and monthly reports generated automatically — no more copy-paste."],
        ["file", "MIS reporting", "Management information reports that consolidate data across teams, branches and periods."],
        ["clock", "Attendance management tools", "Track check-ins, late marks, overtime and leave balances with automatic summaries."],
        ["wallet", "Payroll calculators", "Salary, deductions, PF/ESI, incentives and payslips calculated accurately every month."],
        ["target", "Performance tracking dashboards", "Targets versus achievement for individuals, teams and regions — visible at a glance."],
        ["box", "Inventory management tools", "Stock in and out, reorder alerts, valuation and movement history in one workbook."],
        ["bars", "Sales tracking systems", "Leads, orders, collections and pipeline tracked with automated summaries."],
        ["search", "Data analysis tools", "Clean, combine and analyse large data sets with Power Query, pivots and formulas."],
        ["zap", "Automated Excel reports", "VBA macros and one-click buttons that format, filter and distribute reports."],
        ["receipt", "Custom business calculators", "Quotation, pricing, costing, EMI and commission calculators built for your rules."],
        ["sheet", "Google Sheets automation", "Apps Script automations, form integrations, scheduled emails and live shared dashboards."],
      ],
      "green"
    )}
  </div>
</section>

<section class="section surface">
  <div class="container">
    ${sectionHead({ eyebrow: "The difference", title: "From manual effort {to automatic answers.}", center: true })}
    <div class="ba mt-l">
      <div class="card before" data-reveal="left"><span class="eyebrow" style="color:var(--rose)">Before</span><ul class="mt-m">
        ${["Hours spent copying data between sheets", "Reports rebuilt by hand every month", "Formula errors that go unnoticed", "Different versions of the same file", "Decisions waiting on someone's spreadsheet"]
          .map((x) => `<li>${icon("close")}${x}</li>`)
          .join("")}</ul></div>
      <div class="card after" data-reveal="right"><span class="eyebrow" style="color:var(--green)">After Velto</span><ul class="mt-m">
        ${["Data flows in automatically from its source", "Reports generated in a single click", "Validation rules that prevent mistakes", "One shared, controlled source of truth", "Live dashboards available whenever you need them"]
          .map((x) => `<li>${icon("check")}${x}</li>`)
          .join("")}</ul></div>
    </div>
  </div>
</section>

<section class="section-sm">
  <div class="container">
    <div class="card" data-reveal style="padding:clamp(28px,4vw,48px)">
      <div class="split">
        <div>${sectionHead({ eyebrow: "Tools & techniques", title: "The right technique {for every task.}" })}</div>
        <div class="tags" data-reveal>${["Advanced formulas", "Pivot tables", "Power Query", "Power Pivot", "VBA macros", "Google Apps Script", "Data validation", "Conditional formatting", "Interactive charts", "Google Forms integration", "Scheduled email reports", "Protected templates"]
          .map((t) => `<span class="tag">${t}</span>`)
          .join("")}</div>
      </div>
    </div>
  </div>
</section>

${processSection({ title: "From messy data to {a tool you love.}" })}
${relatedServices("excel-automation")}
${ctaSection({ eyebrow: "Excel automation", title: "Automate {your business.}", primary: "Automate Your Business", href: "/contact/?service=excel-automation" })}
`,
};
