import { site, services, industries } from "../data.mjs";
import { icon } from "../icons.mjs";
import { markSVG } from "../brand.mjs";
import { ico } from "../layout.mjs";
import { bgFx, splitText, sectionHead, btn, ctaSection, serviceCard, processSection, heroVisual } from "../components.mjs";

const why = [
  ["wallet", "cyan", "Affordable by design", "Transparent, right-sized pricing. You pay for what moves your business — not for bloated features or agency overhead.", "span-3"],
  ["layers", "violet", "One partner, end to end", "Websites, apps, software, automation and back-office support under one roof — so nothing gets lost between vendors.", "span-3"],
  ["workflow", "blue", "Built around your process", "We adapt technology to how you work, not the other way around.", ""],
  ["message", "green", "Clear communication", "Plain language, regular updates and a single point of contact.", ""],
  ["shield", "amber", "Secure & dependable", "Security-conscious builds, sensible backups and access control by default.", ""],
];

const tech = [
  ["Next.js", "0deg", "50%"], ["Flutter", "60deg", "50%"], ["Node.js", "120deg", "50%"], ["Python", "180deg", "50%"], ["Cloud", "240deg", "50%"], ["REST APIs", "300deg", "50%"],
];
const tech2 = [["React", "30deg"], ["Apps Script", "120deg"], ["Excel VBA", "210deg"], ["SQL", "300deg"]];

export default {
  path: "/",
  title: "Velto — Website, App & Custom Software Development, BPO, Excel Automation & HRMS",
  description:
    "Velto builds websites, mobile apps and custom software, automates work with Excel and HRMS solutions, and supports operations with BPO services — affordable technology that moves business forward.",
  body: () => `
<section class="hero" data-hero>
  <canvas class="hero-canvas" data-network aria-hidden="true"></canvas>
  ${bgFx({ grid: true, blobs: true })}
  <div class="container">
    <div class="hero-grid">
      <div data-hero-copy>
        <span class="pill" data-reveal><span class="dot"></span>Technology · Automation · Operations</span>
        ${splitText("Building Technology. {Empowering Businesses.}", "h1", "display")}
        <p class="lead" data-reveal style="--d:.35s">Velto helps startups, small businesses and growing companies build websites, apps and custom software, automate everyday work, and run smoother operations — with one accessible, accountable technology partner.</p>
        <div class="btn-row" data-reveal style="--d:.45s">
          ${btn("Explore Our Solutions", "/services/", "primary", "data-magnetic")}
          <a class="btn btn-ghost" href="/contact/" data-magnetic>Let's Talk</a>
        </div>
        <div class="hero-meta" data-reveal style="--d:.55s"><span>${icon("check")}Custom-built for you</span><span>${icon("check")}Transparent pricing</span><span>${icon("check")}Support after launch</span></div>
      </div>
      <div data-reveal="scale" style="--d:.2s">${heroVisual()}</div>
    </div>
  </div>
  <div class="scroll-cue" aria-hidden="true"></div>
</section>

<div class="marquee" aria-hidden="true"><div class="marquee-track">${[0, 1]
    .map(() => ["Website Development", "Mobile Apps", "Custom Software", "BPO Services", "Excel Automation", "HRMS", "Process Consulting", "IT Support", "Digital Transformation"].map((t) => `<span>${t}</span>`).join(""))
    .join("")}</div></div>

<section class="section">
  <div class="container">
    <div class="split wide-left">
      <div>
        <span class="eyebrow" data-reveal>Who we are</span>
        <p class="statement mt-m" data-scrub>Velto is a technology and business solutions partner. We design, build and run the digital tools that help businesses work smarter, serve customers better and grow with confidence.</p>
      </div>
      <div data-reveal="right">
        <p class="lead">Modern technology shouldn't be reserved for large enterprises. We bring the same thinking, tools and quality that big companies rely on — made practical, affordable and accessible for businesses of every size.</p>
        <ul class="check-list mt-m">
          <li>${icon("check")}Technology that solves real business problems</li>
          <li>${icon("check")}Solutions tailored to your size, workflow and budget</li>
          <li>${icon("check")}Ongoing support long after launch day</li>
        </ul>
        <div class="mt-m"><a class="link-arrow" href="/about/">More about Velto ${icon("arrowRight")}</a></div>
      </div>
    </div>
  </div>
</section>

<section class="section surface">
  <div class="container">
    <div class="split">
      ${sectionHead({ eyebrow: "What we do", title: "Everything your business needs to {run on technology.}" })}
      <p class="lead" data-reveal>From your first website to a fully automated back office, Velto covers the full journey: build the product, automate the routine, and support the operation — so you can focus on customers and growth.</p>
    </div>
    <div class="grid g-3 mt-l">${services.map(serviceCard).join("")}</div>
    <div class="center mt-l" data-reveal>${btn("View All Services", "/services/")}</div>
  </div>
</section>

<section class="section">
  <div class="container">
    ${sectionHead({ eyebrow: "Why choose Velto", title: "Serious technology. {Human partnership.}", lead: "We combine engineering quality with practical business sense — and we stay accountable for results.", center: true })}
    <div class="bento mt-l">
      ${why
        .map(
          ([ic, hue, t, d, span], i) => `<div class="card ${span}" data-reveal style="--d:${(i % 3) * 0.08}s" data-spotlight>${ico(ic, hue)}<h3 class="h4">${t}</h3><p>${d}</p>${
            i === 0
              ? `<div class="feature-visual" aria-hidden="true"><svg viewBox="0 0 400 150" preserveAspectRatio="none" style="width:100%;height:100%"><defs><linearGradient id="fv1" x1="0" x2="1"><stop stop-color="#22D3EE"/><stop offset="1" stop-color="#8B5CF6"/></linearGradient><linearGradient id="fv2" x1="0" x2="0" y1="0" y2="1"><stop stop-color="#2F6BFF" stop-opacity=".35"/><stop offset="1" stop-color="#2F6BFF" stop-opacity="0"/></linearGradient></defs><path d="M0 120 C60 115 90 95 140 92 S220 70 260 60 340 30 400 20 V150 H0Z" fill="url(#fv2)"/><path class="draw-line" d="M0 120 C60 115 90 95 140 92 S220 70 260 60 340 30 400 20" fill="none" stroke="url(#fv1)" stroke-width="3"/></svg></div>`
              : i === 1
              ? `<div class="feature-visual" aria-hidden="true" style="display:flex;align-items:center;justify-content:center;gap:10px;flex-wrap:wrap;padding:16px">${["Build", "Automate", "Operate", "Support"]
                  .map((x) => `<span class="tag">${x}</span>`)
                  .join(`<span style="color:var(--dim)">→</span>`)}</div>`
              : ""
          }</div>`
        )
        .join("")}
    </div>
  </div>
</section>

<section class="section-sm">
  <div class="container">
    <div class="stats" data-reveal>
      <div class="stat"><div class="stat-num"><span data-count="9">9</span></div><p>Core service lines under one roof</p></div>
      <div class="stat"><div class="stat-num"><span data-count="17">17</span><span class="suffix">+</span></div><p>HRMS modules available to configure</p></div>
      <div class="stat"><div class="stat-num"><span data-count="12">12</span></div><p>Types of Excel & Sheets business tools we build</p></div>
      <div class="stat"><div class="stat-num"><span data-count="100">100</span><span class="suffix">%</span></div><p>Custom-built — no one-size-fits-all templates</p></div>
    </div>
    <p class="note mt-s">Figures describe Velto's service catalogue. Client performance metrics will be published as projects are completed.</p>
  </div>
</section>

<section class="section">
  <div class="container">
    ${sectionHead({ eyebrow: "Industries we support", title: "Built for the way {your industry works.}", lead: "Every sector has its own workflows, rules and customers. We tailor each solution to fit." })}
    <div class="industries mt-l">${industries
      .map(([ic, t], i) => `<div class="industry" data-reveal style="--d:${(i % 5) * 0.05}s">${icon(ic)}<strong>${t}</strong></div>`)
      .join("")}</div>
  </div>
</section>

<section class="section surface" style="overflow:hidden">
  <div class="divider-glow"></div>
  <div class="container">
    <div class="split">
      <div>
        ${sectionHead({ eyebrow: "Technology & innovation", title: "Modern stack. {Practical outcomes.}", lead: "We choose proven, well-supported technologies so what we build is fast, secure and easy to maintain — and we apply automation and AI only where they create real value." })}
        <ul class="check-list mt-m" data-reveal>
          <li>${icon("check")}Responsive, performance-first web and mobile engineering</li>
          <li>${icon("check")}Cloud-ready architecture that scales with you</li>
          <li>${icon("check")}Automation across spreadsheets, email, HR and reporting</li>
          <li>${icon("check")}Clean integrations with the tools you already use</li>
        </ul>
      </div>
      <div class="orbit" data-reveal="scale" aria-hidden="true">
        <div class="orbit-ring o1">${tech.map(([n, a]) => `<div class="orbit-chip" style="--a:${a};--r:50cqw"><span>${n}</span></div>`).join("")}</div>
        <div class="orbit-ring o2">${tech2.map(([n, a]) => `<div class="orbit-chip" style="--a:${a};--r:33cqw"><span>${n}</span></div>`).join("")}</div>
        <div class="orbit-ring o3"></div>
        <div class="orbit-center">${markSVG({ id: "orbc" })}</div>
      </div>
    </div>
  </div>
</section>

${processSection()}

${ctaSection({ eyebrow: "Client inquiry", title: "Have a project in mind? {Let's talk.}", lead: "Share your idea, challenge or requirement. We'll reply with practical recommendations and a clear, no-obligation estimate." })}
`,
};
