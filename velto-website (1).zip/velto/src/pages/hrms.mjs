import { icon } from "../icons.mjs";
import { ico } from "../layout.mjs";
import { sectionHead, pageHero, btn, ctaSection, processSection, hrmsDashboard, relatedServices } from "../components.mjs";
import { getService } from "../data.mjs";

const s = getService("hrms");

const modules = [
  ["users", "Employee management"], ["database", "Employee database"], ["clock", "Attendance management"], ["calendar", "Leave management"],
  ["wallet", "Payroll management"], ["userPlus", "Recruitment management"], ["userCheck", "Employee onboarding"], ["target", "Performance management"],
  ["refresh", "Shift & roster management"], ["calendar", "Holiday calendar"], ["file", "Document management"], ["laptop", "Asset management"],
  ["receipt", "Expense management"], ["idCard", "Employee self-service portal"], ["chart", "HR reports & analytics"], ["key", "Role-based access"],
  ["workflow", "Workflow & approvals"],
];

export default {
  path: "/services/hrms/",
  title: s.seoTitle,
  description: s.seoDescription,
  service: s,
  body: () => `
${pageHero({
  crumbs: [["Services", "/services/"], ["HRMS Solutions"]],
  eyebrow: "HRMS & HR Automation",
  title: "One HR platform. {Built around your people.}",
  lead: "Velto delivers a customizable HRMS that brings employee records, attendance, leave, payroll, recruitment and performance into one secure system — configured to your company's size, policies and approval flows.",
  actions: btn("Get Your Custom HRMS", "/contact/?service=hrms", "primary", "data-magnetic") + `<a class="btn btn-ghost" href="#modules">See all modules</a>`,
  visual: hrmsDashboard(),
})}

<section class="section" id="modules" style="scroll-margin-top:90px">
  <div class="container">
    ${sectionHead({ eyebrow: "Modules", title: "Everything HR needs, {in one place.}", lead: "Start with the modules you need today and switch on more as you grow." })}
    <div class="modules mt-l">${modules.map(([ic, t], i) => `<div class="module" data-reveal style="--d:${(i % 4) * 0.05}s">${icon(ic)}${t}</div>`).join("")}</div>
  </div>
</section>

<section class="section surface">
  <div class="container">
    ${sectionHead({ eyebrow: "Tailored to you", title: "Customized for your {size and requirements.}", lead: "No two organisations run HR the same way. We configure policies, salary structures, shifts, approval hierarchies and reports to match yours.", center: true })}
    <div class="grid g-3 mt-l">
      ${[
        ["rocket", "cyan", "Small teams", "Up to 50 employees", "Get organised quickly with employee records, attendance, leave and payroll in one simple, affordable system."],
        ["building", "blue", "Growing companies", "50 – 500 employees", "Add recruitment, onboarding, shifts, performance reviews and multi-level approvals as your teams expand."],
        ["layers", "violet", "Larger organisations", "500+ employees, multi-location", "Branch-wise policies, role-based access, advanced analytics and integrations with your existing systems."],
      ]
        .map(
          ([ic, hue, t, sz, d], i) =>
            `<div class="card lift size-card" data-reveal style="--d:${i * 0.08}s" data-spotlight>${ico(ic, hue, "lg")}<h3 class="h3">${t}</h3><p class="size mt-s">${sz}</p><p>${d}</p></div>`
        )
        .join("")}
    </div>
  </div>
</section>

<section class="section">
  <div class="container">
    <div class="split">
      <div>
        ${sectionHead({ eyebrow: "Why it matters", title: "Less admin. {Happier people.}", lead: "An HRMS removes repetitive paperwork, prevents payroll mistakes and gives employees instant answers — so HR can focus on people, not spreadsheets." })}
      </div>
      <div class="grid g-2">
        ${[
          ["zap", "violet", "Automated workflows", "Leave, expense and attendance approvals routed automatically."],
          ["checkCircle", "green", "Accurate payroll", "Attendance-linked salaries, statutory deductions and payslips."],
          ["idCard", "cyan", "Self-service", "Employees view payslips, apply for leave and update details themselves."],
          ["shield", "blue", "Secure & compliant", "Role-based access, audit trails and protected employee data."],
        ]
          .map(([ic, hue, t, d], i) => `<div class="card" data-reveal style="--d:${i * 0.06}s" data-spotlight>${ico(ic, hue)}<h3 class="h4">${t}</h3><p>${d}</p></div>`)
          .join("")}
      </div>
    </div>
  </div>
</section>

${processSection({ title: "Your HRMS, {configured and live.}", lead: "We map your HR policies, configure the system, migrate your employee data and train your team — step by step." })}
${relatedServices("hrms")}
${ctaSection({ eyebrow: "HRMS solutions", title: "Get your {custom HRMS.}", primary: "Get Your Custom HRMS", href: "/contact/?service=hrms" })}
`,
};
