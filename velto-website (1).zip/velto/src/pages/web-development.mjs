import { icon } from "../icons.mjs";
import { ico } from "../layout.mjs";
import { sectionHead, pageHero, btn, ctaSection, processSection, offerGrid, browserMockup, phone, relatedServices } from "../components.mjs";
import { getService } from "../data.mjs";

const s = getService("web-development");

export default {
  path: "/services/web-development/",
  title: s.seoTitle,
  description: s.seoDescription,
  service: s,
  body: () => `
${pageHero({
  crumbs: [["Services", "/services/"], ["Web Development"]],
  eyebrow: "Website Development",
  title: "Websites that look premium {and perform even better.}",
  lead: "From a sharp business website to a full e-commerce store or custom web application, Velto builds fast, responsive, search-friendly sites designed to win trust and generate enquiries.",
  actions: btn("Build Your Website With Velto", "/contact/?service=web-development", "primary", "data-magnetic") + `<a class="btn btn-ghost" href="#what-we-build">What we build</a>`,
  visual: `<div class="devices">${browserMockup()}<div class="phone-float" style="position:absolute;right:-1%;bottom:-5%;width:19%;min-width:110px" data-parallax="0.04">${phone("shop")}</div></div>`,
})}

<section class="section" id="what-we-build" style="scroll-margin-top:90px">
  <div class="container">
    ${sectionHead({ eyebrow: "What we build", title: "Every kind of website {your business needs.}" })}
    ${offerGrid(
      [
        ["briefcase", "Business websites", "Professional websites that present your services clearly and turn visitors into calls, messages and enquiries."],
        ["cart", "E-commerce websites", "Online stores with product catalogues, secure payments, order management and a smooth checkout."],
        ["building", "Corporate websites", "Polished multi-page sites that communicate credibility to clients, partners and future employees."],
        ["target", "Landing pages", "Focused, high-converting pages for campaigns, launches and lead generation."],
        ["code", "Custom web applications", "Portals, dashboards, booking systems and internal tools that run in the browser."],
        ["refresh", "Website redesign", "Modernize an outdated site with a new design, better structure, faster speed and stronger SEO."],
        ["wrench", "Website maintenance", "Updates, backups, security monitoring, content changes and performance tuning."],
        ["search", "Responsive & SEO-friendly", "Mobile-first builds with clean code, structured data and the technical SEO search engines expect."],
        ["gauge", "Speed optimization", "Lightweight pages, optimized images and modern hosting for fast load times on any connection."],
      ],
      "blue"
    )}
  </div>
</section>

<section class="section surface">
  <div class="container">
    <div class="split">
      <div>
        ${sectionHead({ eyebrow: "Built right", title: "Beautiful outside. {Engineered inside.}", lead: "Good design wins attention. Good engineering keeps it — with fast loading, accessibility and rankings that hold up over time." })}
        <div class="btn-row mt-m" data-reveal>${btn("Start Your Website", "/contact/?service=web-development")}</div>
      </div>
      <div class="grid g-2">
        ${[
          ["phone", "cyan", "Mobile-first", "Designed for phones first, then scaled up beautifully to tablets and desktops."],
          ["search", "blue", "SEO foundations", "Clean URLs, metadata, sitemaps, schema markup and fast performance."],
          ["shield", "green", "Secure by default", "HTTPS, protected forms, spam filtering and regular updates."],
          ["layers", "violet", "Easy to manage", "Update content yourself, or let us handle changes for you."],
        ]
          .map(([ic, hue, t, d], i) => `<div class="card" data-reveal style="--d:${i * 0.06}s" data-spotlight>${ico(ic, hue)}<h3 class="h4">${t}</h3><p>${d}</p></div>`)
          .join("")}
      </div>
    </div>
  </div>
</section>

${processSection({ title: "From idea to launch, {without the guesswork.}" })}
${relatedServices("web-development")}
${ctaSection({ eyebrow: "Web development", title: "Build your website {with Velto.}", primary: "Build Your Website With Velto", href: "/contact/?service=web-development" })}
`,
};
