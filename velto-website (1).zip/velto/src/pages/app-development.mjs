import { icon } from "../icons.mjs";
import { ico } from "../layout.mjs";
import { sectionHead, pageHero, btn, ctaSection, processSection, offerGrid, phonesShowcase, relatedServices } from "../components.mjs";
import { getService } from "../data.mjs";

const s = getService("app-development");

export default {
  path: "/services/app-development/",
  title: s.seoTitle,
  description: s.seoDescription,
  service: s,
  body: () => `
${pageHero({
  crumbs: [["Services", "/services/"], ["App Development"]],
  eyebrow: "Mobile Application Development",
  title: "Apps your customers {love to open.}",
  lead: "Velto designs and develops Android, iOS and cross-platform applications that are fast, intuitive and built around real business goals — from customer-facing commerce apps to internal tools for your team.",
  actions: btn("Let's Build Your App", "/contact/?service=app-development", "primary", "data-magnetic") + `<a class="btn btn-ghost" href="#capabilities">Capabilities</a>`,
  visual: phonesShowcase(),
  center: true,
})}

<section class="section" id="capabilities" style="scroll-margin-top:90px">
  <div class="container">
    ${sectionHead({ eyebrow: "Capabilities", title: "End-to-end {mobile development.}" })}
    ${offerGrid(
      [
        ["phone", "Android applications", "Native-quality Android apps published on Google Play, optimized for the wide range of devices your customers use."],
        ["phone", "iOS applications", "Polished iPhone and iPad apps that meet Apple's design standards and App Store requirements."],
        ["layers", "Cross-platform apps", "One codebase for Android and iOS using Flutter or React Native — faster delivery and lower cost."],
        ["briefcase", "Business applications", "Field-force, sales, inventory, approval and reporting apps that keep your team productive anywhere."],
        ["cart", "E-commerce apps", "Shopping apps with catalogues, carts, payments, order tracking and push notifications."],
        ["sparkles", "Custom app development", "Booking, delivery, education, healthcare or entirely new ideas — built to your specification."],
        ["link", "API integrations", "Connect your app to payment gateways, CRMs, ERPs, maps, messaging and your own backend."],
        ["wrench", "App maintenance", "OS updates, bug fixes, performance monitoring, store compliance and new feature releases."],
        ["gauge", "Performance & analytics", "Fast startup, smooth scrolling and in-app analytics so you know how people use your app."],
      ],
      "violet"
    )}
  </div>
</section>

<section class="section surface">
  <div class="container">
    ${sectionHead({ eyebrow: "Choose your path", title: "The right platform {for your goals.}", center: true })}
    <div class="grid g-3 mt-l">
      ${[
        ["phone", "green", "Native Android", "Best when your audience is primarily Android and you need deep device integration.", ["Kotlin / Java", "Google Play publishing", "Device features & offline mode"]],
        ["layers", "violet", "Cross-platform", "The most cost-effective route to both stores with a single, shared codebase.", ["Flutter or React Native", "Android + iOS together", "Faster updates, lower cost"]],
        ["phone", "blue", "Native iOS", "Ideal for premium experiences and Apple-centric audiences.", ["Swift / SwiftUI", "App Store publishing", "Apple design guidelines"]],
      ]
        .map(
          ([ic, hue, t, d, l], i) =>
            `<div class="card lift" data-reveal style="--d:${i * 0.08}s" data-spotlight>${ico(ic, hue, "lg")}<h3 class="h3">${t}</h3><p>${d}</p><ul class="check-list">${l
              .map((x) => `<li>${icon("check")}${x}</li>`)
              .join("")}</ul></div>`
        )
        .join("")}
    </div>
  </div>
</section>

${processSection({ title: "From concept to {app store launch.}" })}
${relatedServices("app-development")}
${ctaSection({ eyebrow: "App development", title: "Let's build {your app.}", primary: "Let's Build Your App", href: "/contact/?service=app-development" })}
`,
};
