import { site } from "../data.mjs";
import { pageHero, bgFx, btn } from "../components.mjs";

export const privacy = {
  path: "/privacy/",
  title: "Privacy Policy",
  description: "How Velto collects, uses and protects the information you share through velto.co.in and our contact form.",
  body: () => `
${pageHero({ crumbs: [["Privacy Policy"]], eyebrow: "Legal", title: "Privacy {Policy}", lead: "Last updated: October 2026" })}
<section class="section-sm" style="padding-top:0"><div class="container"><div class="prose">
<p>This Privacy Policy explains how Velto ("we", "us") handles personal information collected through ${site.displayUrl}. We collect only what we need to respond to you and we never sell your data.</p>
<h2>Information we collect</h2>
<p>When you submit our contact form, we collect the details you provide: your name, company name (optional), phone number, email address, the service you are interested in, your budget range (optional) and your message. Our servers also process your IP address temporarily to prevent spam and abuse.</p>
<h2>How we use it</h2>
<ul><li>To respond to your inquiry and discuss your requirements.</li><li>To prepare proposals, estimates and project communication.</li><li>To protect the website against spam and misuse.</li></ul>
<h2>How it is stored and shared</h2>
<p>Form submissions are delivered to our business email inbox using a secure email service provider. We do not share your information with third parties for marketing. Service providers that help us operate the website (such as hosting and email delivery) process data only on our behalf.</p>
<h2>Cookies</h2>
<p>This website does not use advertising or tracking cookies. Your browser's session storage is used only to remember that the opening animation has already been shown.</p>
<h2>Your choices</h2>
<p>You can ask us to access, correct or delete the information you have shared by emailing <a href="${site.emailHref}">${site.email}</a> or calling <a href="${site.phoneHref}">${site.phone}</a>.</p>
<h2>Contact</h2>
<p>Questions about this policy? Email <a href="${site.emailHref}">${site.email}</a>.</p>
</div></div></section>
`,
};

export const notFound = {
  path: "/404.html",
  title: "Page Not Found",
  description: "The page you're looking for doesn't exist. Explore Velto's services or get in touch.",
  noindex: true,
  body: () => `
<section class="notfound">${bgFx()}
  <div class="z1">
    <div class="code" data-reveal>404</div>
    <h1 class="h2" data-reveal style="--d:.1s">This page moved forward without you.</h1>
    <p class="lead mt-s" data-reveal style="--d:.2s">The page you're looking for doesn't exist or has been moved.</p>
    <div class="btn-row mt-m" data-reveal style="--d:.3s;justify-content:center">${btn("Back to Home", "/")}<a class="btn btn-ghost" href="/services/">Explore Services</a></div>
  </div>
</section>`,
};
