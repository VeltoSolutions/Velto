import { site, nav, services, serviceHref } from "./data.mjs";
import { icon, whatsapp, social } from "./icons.mjs";
import { markSVG, wordSVG } from "./brand.mjs";

export const esc = (s = "") =>
  String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");

export const logo = (id = "h") =>
  `${markSVG({ id: id + "m" })}${wordSVG({ id: id + "w" })}`;

export const ico = (name, hue = "cyan", cls = "") => `<span class="ico hue-${hue} ${cls}">${icon(name)}</span>`;

const isActive = (href, path) => (href === "/" ? path === "/" : path.startsWith(href));

const megaBlurb = {
  "technology-solutions": "Strategy, cloud & integrations",
  "web-development": "Websites, stores & web apps",
  "app-development": "Android, iOS & cross-platform",
  "custom-software": "Systems built around your workflow",
  bpo: "Customer support & back office",
  "excel-automation": "Dashboards, MIS & smart tools",
  hrms: "Attendance, leave & payroll",
  "business-consulting": "Process mapping & optimization",
  "it-support": "Helpdesk & modernization",
};

function header(path) {
  const megaItems = services
    .map(
      (s) => `<a class="mega-item" href="${serviceHref(s.slug)}">${ico(s.icon, s.hue)}<div><strong>${esc(s.short)}</strong><span>${esc(megaBlurb[s.slug] || "")}</span></div></a>`
    )
    .join("");

  const desktopNav = nav
    .map((n) => {
      const active = isActive(n.href, path) ? " is-active" : "";
      if (n.mega)
        return `<li class="has-mega"><button class="nav-link${active}" type="button" aria-expanded="false" aria-controls="mega-services" data-mega-toggle>${n.label}${icon("chevronDown")}</button>
<div class="mega" id="mega-services" data-mega><div class="mega-inner"><div class="mega-grid">${megaItems}</div>
<a class="mega-feature" href="/services/">${markSVG({ id: "mfm" })}<strong>Explore all services</strong><p>One partner for technology, automation and operations — built around your business.</p><span class="link-arrow">View services ${icon("arrowRight", "icon icon-arrow")}</span></a></div></div></li>`;
      return `<li><a class="nav-link${active}" href="${n.href}"${active ? ' aria-current="page"' : ""}>${n.label}</a></li>`;
    })
    .join("");

  const mobileNav = nav
    .map((n) => {
      const active = isActive(n.href, path) ? " is-active" : "";
      if (n.mega)
        return `<li><button class="m-link${active}" type="button" aria-expanded="false" aria-controls="m-services" data-m-toggle>${n.label}${icon("chevronDown")}</button>
<div class="m-sub" id="m-services"><div><ul><li><a href="/services/">${ico("layers", "blue")}All services</a></li>${services
          .map((s) => `<li><a href="${serviceHref(s.slug)}">${ico(s.icon, s.hue)}${esc(s.short)}</a></li>`)
          .join("")}</ul></div></div></li>`;
      return `<li><a class="m-link${active}" href="${n.href}">${n.label}${icon("arrowUpRight")}</a></li>`;
    })
    .join("");

  return `<header class="site-header" data-header>
  <div class="container">
    <a class="brand" href="/" aria-label="Velto home">${logo("hd")}</a>
    <nav aria-label="Main"><ul class="nav">${desktopNav}</ul></nav>
    <div class="header-cta">
      <a class="btn btn-primary btn-sm" href="/contact/" data-magnetic>Get a Quote ${icon("arrowRight", "icon icon-arrow")}</a>
      <button class="menu-toggle" type="button" aria-label="Open menu" aria-expanded="false" aria-controls="mobile-menu" data-menu-toggle><span></span><span></span></button>
    </div>
  </div>
</header>
<div class="mobile-menu" id="mobile-menu" aria-label="Mobile">
  <ul>${mobileNav}</ul>
  <div class="m-foot">
    <a class="btn btn-primary btn-block" href="/contact/">Get a Quote ${icon("arrowRight", "icon icon-arrow")}</a>
    <a class="btn btn-ghost btn-block" href="${site.whatsappHref}" target="_blank" rel="noopener">${whatsapp()} Chat on WhatsApp</a>
    <div class="m-contact"><a href="${site.phoneHref}">${site.phone}</a><span class="text-dim">·</span><a href="${site.emailHref}">${site.email}</a></div>
  </div>
</div>`;
}

function footer() {
  const quick = nav.map((n) => `<li><a href="${n.href}">${n.label}</a></li>`).join("");
  const footServices = ["web-development", "app-development", "bpo", "excel-automation", "hrms", "custom-software"]
    .map((slug) => services.find((s) => s.slug === slug))
    .map((s) => `<li><a href="${serviceHref(s.slug)}">${esc(s.short)}</a></li>`)
    .join("");
  const socials = ["linkedin", "instagram", "facebook"]
    .map((k) => {
      const name = { linkedin: "LinkedIn", instagram: "Instagram", facebook: "Facebook" }[k];
      return site.social[k]
        ? `<a class="social" href="${esc(site.social[k])}" target="_blank" rel="noopener" aria-label="Velto on ${name}">${social[k]}</a>`
        : `<span class="social" tabindex="0" role="img" aria-label="${name} — coming soon" data-tip="${name} · coming soon">${social[k]}</span>`;
    })
    .join("");
  return `<footer class="site-footer">
  <div class="glow"></div>
  <div class="container">
    <div class="foot-grid">
      <div class="foot-brand">
        <a class="brand" href="/" aria-label="Velto home">${logo("ft")}</a>
        <p class="tagline">${esc(site.tagline)}</p>
        <p>Websites, apps, custom software, automation and operational support — accessible technology for businesses of every size.</p>
        <div class="socials">${socials}</div>
      </div>
      <div class="foot-col"><h4>Quick Links</h4><ul>${quick}</ul></div>
      <div class="foot-col"><h4>Services</h4><ul>${footServices}</ul></div>
      <div class="foot-col foot-contact"><h4>Contact</h4><ul>
        <li>${icon("call")}<a href="${site.phoneHref}">${site.phone}</a></li>
        <li>${icon("mail")}<a href="${site.emailHref}">${site.email}</a></li>
        <li>${icon("globe")}<a href="${site.url}">${site.displayUrl}</a></li>
        <li>${whatsapp("icon")}<a href="${site.whatsappHref}" target="_blank" rel="noopener">WhatsApp us</a></li>
      </ul></div>
    </div>
    <div class="foot-word" aria-hidden="true">${wordSVG({ id: "fbw", cls: "", color: "currentColor" })}</div>
    <div class="foot-bottom"><span>© ${site.year} Velto. All Rights Reserved.</span><span><a href="/privacy/">Privacy Policy</a> · <a href="/contact/">Contact</a></span></div>
  </div>
</footer>
<a class="wa-fab" href="${site.whatsappHref}" target="_blank" rel="noopener" aria-label="Chat with Velto on WhatsApp">${whatsapp()}</a>`;
}

const loader = () => `<div class="loader" aria-hidden="true" data-loader><div class="loader-inner">${markSVG({ id: "ldm" })}${wordSVG({ id: "ldw" })}<div class="loader-bar"><i></i></div></div></div>`;

export function page({ path, title, description, body, jsonLd = [], ogType = "website", noindex = false }) {
  const canonical = site.url + (path === "/404.html" ? "/" : path);
  const fullTitle = path === "/" ? title : `${title} | Velto`;
  const org = {
    "@context": "https://schema.org",
    "@type": "Organization",
    "@id": site.url + "/#organization",
    name: "Velto",
    url: site.url,
    logo: site.url + "/assets/brand/velto-symbol.png",
    email: site.email,
    telephone: "+91-98889-88510",
    slogan: site.tagline,
    contactPoint: [{ "@type": "ContactPoint", telephone: "+91-98889-88510", email: site.email, contactType: "sales", areaServed: "IN", availableLanguage: ["English", "Hindi"] }],
  };
  const ld = [org, ...jsonLd].map((o) => `<script type="application/ld+json">${JSON.stringify(o).replace(/</g, "\\u003c")}</script>`).join("\n");

  return `<!doctype html>
<html lang="en-IN" class="no-js">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>${esc(fullTitle)}</title>
<meta name="description" content="${esc(description)}">
<link rel="canonical" href="${canonical}">
<meta name="robots" content="${noindex ? "noindex, follow" : "index, follow, max-image-preview:large"}">
<meta name="theme-color" content="#05060A">
<meta name="format-detection" content="telephone=no">
<meta property="og:type" content="${ogType}">
<meta property="og:site_name" content="Velto">
<meta property="og:locale" content="en_IN">
<meta property="og:title" content="${esc(fullTitle)}">
<meta property="og:description" content="${esc(description)}">
<meta property="og:url" content="${canonical}">
<meta property="og:image" content="${site.url}/assets/brand/og-image.png">
<meta property="og:image:width" content="1200">
<meta property="og:image:height" content="630">
<meta property="og:image:alt" content="Velto — Technology That Moves Business Forward">
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="${esc(fullTitle)}">
<meta name="twitter:description" content="${esc(description)}">
<meta name="twitter:image" content="${site.url}/assets/brand/og-image.png">
<link rel="icon" href="/favicon.ico" sizes="48x48">
<link rel="icon" href="/favicon.svg" type="image/svg+xml">
<link rel="apple-touch-icon" href="/apple-touch-icon.png">
<link rel="manifest" href="/site.webmanifest">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&family=Sora:wght@500;600&display=swap">
<link rel="stylesheet" href="/assets/css/styles.css?v=__V__">
<script>document.documentElement.className="js";try{if(sessionStorage.getItem("velto-seen"))document.documentElement.classList.add("seen")}catch(e){}</script>
${ld}
</head>
<body>
<a class="skip-link" href="#main">Skip to content</a>
${loader()}
<div class="page-veil" aria-hidden="true"></div>
${header(path)}
<main id="main">
${body}
</main>
${footer()}
<script src="/assets/js/main.js?v=__V__" defer></script>
</body>
</html>`;
}
