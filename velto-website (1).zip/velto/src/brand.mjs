// VELTO brand system — the "Vector Node" mark.
// Concept: a V formed by two momentum strokes. The rising stroke launches a detached node
// forward and upward — technology (node), movement (vector) and growth (ascent) in one symbol.
// All geometry is hand-built paths, so it renders identically everywhere (no font dependency).

export const brand = {
  cyan: "#22D3EE",
  blue: "#2F6BFF",
  violet: "#8B5CF6",
  ink: "#05060A",
  navy: "#0B1226",
  white: "#F5F7FB",
};

const gradient = (id) =>
  `<linearGradient id="${id}" x1="6" y1="8" x2="42" y2="40" gradientUnits="userSpaceOnUse"><stop stop-color="${brand.cyan}"/><stop offset=".5" stop-color="${brand.blue}"/><stop offset="1" stop-color="${brand.violet}"/></linearGradient>`;

// Symbol geometry, 48×48 grid
const markPaths = (id, nodeColor, back = ".55") =>
  `<path d="M10 13.5 22.5 37" stroke="url(#${id})" stroke-width="6.5" stroke-linecap="round" opacity="${back}"/>` +
  `<path d="M22.5 37 33.5 16.5" stroke="url(#${id})" stroke-width="6.5" stroke-linecap="round"/>` +
  `<circle cx="38.6" cy="8.6" r="4" fill="${nodeColor}"/>`;

// Wordmark geometry, 106×24 grid. Geometric monoline letters; the O carries the brand gradient.
const wordPaths = (id, color) =>
  `<g stroke="${color}" stroke-width="3.2" stroke-linecap="round" stroke-linejoin="round" fill="none">` +
  `<path d="M1.6 3 9 21 16.4 3"/>` +
  `<path d="M37 3H25v18h12M25 12h10"/>` +
  `<path d="M45.5 3v18h11"/>` +
  `<path d="M64.5 3h14M71.5 3v18"/>` +
  `</g><circle cx="95.5" cy="12" r="9" stroke="url(#${id})" stroke-width="3.2" fill="none"/>`;

// Inline symbol for the website (node colour follows currentColor)
export function markSVG({ id = "vm", cls = "logo-mark", node = "currentColor", title = "" } = {}) {
  return `<svg class="${cls}" viewBox="0 0 48 48" fill="none" ${title ? `role="img" aria-label="${title}"` : 'aria-hidden="true"'}><defs>${gradient(id)}</defs>${markPaths(id, node)}</svg>`;
}

export function wordSVG({ id = "vw", cls = "logo-word", color = "currentColor" } = {}) {
  // gradient for the O uses its own coordinate space
  const g = `<linearGradient id="${id}" x1="86.5" y1="3" x2="104.5" y2="21" gradientUnits="userSpaceOnUse"><stop stop-color="${brand.cyan}"/><stop offset=".5" stop-color="${brand.blue}"/><stop offset="1" stop-color="${brand.violet}"/></linearGradient>`;
  return `<svg class="${cls}" viewBox="0 0 106 24" fill="none" aria-hidden="true"><defs>${g}</defs>${wordPaths(id, color)}</svg>`;
}

// Standalone files ---------------------------------------------------------
const OGRAD = `<linearGradient id="wo" x1="86.5" y1="3" x2="104.5" y2="21" gradientUnits="userSpaceOnUse"><stop stop-color="${brand.cyan}"/><stop offset=".5" stop-color="${brand.blue}"/><stop offset="1" stop-color="${brand.violet}"/></linearGradient>`;

export function lockupFile({ text, node, bg, back = ".55" }) {
  // Horizontal lockup: symbol + wordmark, 176×48
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 164 48" width="656" height="192" fill="none"><title>VELTO</title><defs>${gradient("m")}${OGRAD}</defs>${
    bg ? `<rect width="164" height="48" fill="${bg}"/>` : ""
  }${markPaths("m", node, back)}<g transform="translate(56 13.4) scale(.93)">${wordPaths("wo", text)}</g></svg>`;
}

export function stackedFile({ text, node, bg, back = ".55" }) {
  // Stacked lockup for square formats (social avatars, app splash)
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 160 160" width="640" height="640" fill="none"><title>VELTO</title><defs>${gradient("m")}${OGRAD}</defs>${
    bg ? `<rect width="160" height="160" fill="${bg}"/>` : ""
  }<g transform="translate(44 18) scale(1.5)">${markPaths("m", node, back)}</g><g transform="translate(27 110) scale(1)">${wordPaths("wo", text)}</g></svg>`;
}

export function symbolFile({ node, bg, radius = 0, pad = 0, back = ".55" }) {
  const s = 48 + pad * 2;
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${s} ${s}" width="512" height="512" fill="none"><title>VELTO</title><defs>${gradient("m")}</defs>${
    bg ? `<rect width="${s}" height="${s}" rx="${radius}" fill="${bg}"/>` : ""
  }<g transform="translate(${pad} ${pad})">${markPaths("m", node, back)}</g></svg>`;
}

// Favicon: symbol on an ink tile so it reads on light and dark browser tabs
export const faviconSVG = () =>
  `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><defs>${gradient("f")}<radialGradient id="fg" cx=".75" cy=".2" r=".9"><stop stop-color="#1A2A5C"/><stop offset="1" stop-color="#05060A"/></radialGradient></defs><rect width="64" height="64" rx="14" fill="url(#fg)"/><g transform="translate(6 7) scale(1.08)" fill="none">${markPaths("f", "#FFFFFF")}</g></svg>`;
