import { site, services, serviceHref, processSteps } from "./data.mjs";
import { icon, whatsapp } from "./icons.mjs";
import { markSVG } from "./brand.mjs";
import { esc, ico } from "./layout.mjs";

export const bgFx = ({ grid = true, blobs = true, noise = true } = {}) =>
  `<div class="bg-fx" aria-hidden="true">${grid ? '<div class="bg-grid"></div>' : ""}${
    blobs ? '<div class="blob b1" data-parallax="-0.12"></div><div class="blob b2" data-parallax="0.1"></div><div class="blob b3"></div>' : ""
  }${noise ? '<div class="noise"></div>' : ""}</div>`;

// Heading whose words rise in on reveal. Pass plain text; wrap phrases to highlight in {braces}.
export function splitText(text, tag = "h2", cls = "h2", extra = "") {
  let i = 0;
  const html = text
    .split(/(\{[^}]+\})/)
    .filter(Boolean)
    .map((chunk) => {
      const grad = chunk.startsWith("{");
      const words = chunk.replace(/[{}]/g, "").trim().split(/\s+/);
      const inner = words
        .map((w) => `<span class="split-line"><span class="split-word" style="--i:${i++}">${esc(w)}</span></span>`)
        .join(" ");
      return grad ? `<span class="gradient-text">${inner}</span>` : inner;
    })
    .join(" ");
  const label = text.replace(/[{}]/g, "");
  return `<${tag} class="${cls}" data-reveal="fade" aria-label="${esc(label)}" ${extra}><span aria-hidden="true">${html}</span></${tag}>`;
}

export function sectionHead({ eyebrow, title, lead, center = false, tag = "h2" }) {
  return `<div class="section-head${center ? " center" : ""}">
  ${eyebrow ? `<span class="eyebrow" data-reveal>${esc(eyebrow)}</span>` : ""}
  ${splitText(title, tag, "h2")}
  ${lead ? `<p class="lead" data-reveal style="--d:.15s">${lead}</p>` : ""}
</div>`;
}

export function pageHero({ crumbs = [], eyebrow, title, lead, actions = "", visual = "", center = false }) {
  const bc = crumbs.length
    ? `<nav aria-label="Breadcrumb"><ol class="crumbs" data-reveal><li><a href="/">Home</a></li>${crumbs
        .map(([label, href]) => (href ? `<li><a href="${href}">${esc(label)}</a></li>` : `<li aria-current="page">${esc(label)}</li>`))
        .join("")}</ol></nav>`
    : "";
  return `<section class="page-hero${center ? " center" : ""}">
  ${bgFx()}
  <div class="container">
    ${bc}
    ${eyebrow ? `<span class="pill" data-reveal><span class="dot"></span>${esc(eyebrow)}</span>` : ""}
    ${splitText(title, "h1", "h1")}
    ${lead ? `<p class="lead" data-reveal style="--d:.2s">${lead}</p>` : ""}
    ${actions ? `<div class="btn-row" data-reveal style="--d:.3s">${actions}</div>` : ""}
    ${visual ? `<div class="hero-visual" data-reveal="scale" style="--d:.35s">${visual}</div>` : ""}
  </div>
</section>`;
}

export const btn = (label, href, kind = "primary", attrs = "") =>
  `<a class="btn btn-${kind}" href="${href}" ${attrs}>${label}${kind === "primary" ? " " + icon("arrowRight", "icon icon-arrow") : ""}</a>`;

export function ctaSection({ eyebrow = "Start a conversation", title, lead, primary = "Let's Talk", href = "/contact/" } = {}) {
  return `<section class="section-sm"><div class="container">
  <div class="cta-panel" data-reveal="scale">
    <div class="bg-fx" aria-hidden="true"><div class="bg-grid"></div><div class="noise"></div></div>
    <div class="z1">
      <span class="eyebrow">${esc(eyebrow)}</span>
      ${splitText(title || "Let's build what moves your {business forward.}", "h2", "h2")}
      <p class="lead">${lead || "Tell us where you are and where you want to be. We'll recommend a practical, affordable path — with no obligation and no jargon."}</p>
      <div class="btn-row">${btn(primary, href, "primary", "data-magnetic")}<a class="btn btn-ghost" href="${site.whatsappHref}" target="_blank" rel="noopener">${whatsapp()} WhatsApp Us</a></div>
      <div class="cta-contacts"><a href="${site.phoneHref}">${icon("call")}${site.phone}</a><a href="${site.emailHref}">${icon("mail")}${site.email}</a></div>
    </div>
  </div>
</div></section>`;
}

export function serviceCard(s, i = 0) {
  return `<a class="card lift card-link" href="${serviceHref(s.slug)}" data-reveal style="--d:${(i % 3) * 0.08}s" data-spotlight>
  ${ico(s.icon, s.hue, "lg")}
  <h3 class="h4">${esc(s.title)}</h3>
  <p>${esc(s.summary)}</p>
  <span class="link-arrow">Explore ${icon("arrowRight", "icon")}</span>
</a>`;
}

export function processSection({ title = "A clear process, {start to finish.}", lead } = {}) {
  return `<section class="section"><div class="container">
  ${sectionHead({ eyebrow: "Our approach", title, lead: lead || "No black boxes. You'll always know what we're working on, what comes next and what it costs." })}
  <div class="process mt-l" data-process>
    <div class="process-line" aria-hidden="true"><i></i></div>
    ${processSteps
      .map(
        ([t, d], i) => `<div class="step" data-reveal style="--d:${i * 0.08}s"><div class="step-num">0${i + 1}</div><h3>${t}</h3><p>${d}</p></div>`
      )
      .join("")}
  </div>
</div></section>`;
}

export function offerGrid(items, hue = "blue", cols = 3) {
  return `<div class="grid g-${cols} mt-l">${items
    .map(
      ([ic, t, d], i) =>
        `<div class="card offer" data-reveal style="--d:${(i % cols) * 0.07}s" data-spotlight>${ico(ic, hue)}<div><h3>${esc(t)}</h3><p>${esc(d)}</p></div></div>`
    )
    .join("")}</div>`;
}

export function relatedServices(currentSlug) {
  const others = services.filter((s) => s.slug !== currentSlug).slice(0, 3);
  // rotate so pages don't all show the same three
  const idx = services.findIndex((s) => s.slug === currentSlug);
  const pick = [1, 3, 5].map((o) => services[(idx + o) % services.length]).filter((s) => s.slug !== currentSlug);
  const list = pick.length === 3 ? pick : others;
  return `<section class="section-sm"><div class="container">
  ${sectionHead({ eyebrow: "Explore more", title: "Related services" })}
  <div class="grid g-3 mt-l">${list.map(serviceCard).join("")}</div>
</div></section>`;
}

/* =====================================================================
   Mockups — built in HTML/CSS/SVG so they stay razor-sharp at any
   resolution (including 4K/retina) and weigh almost nothing.
   ===================================================================== */

export function browserMockup() {
  const demos = [
    ["Corporate", `<div class="sd-nav"><div class="sd-logo"></div><div class="sd-links"><i></i><i></i><i></i><i></i></div><div class="sd-btn"></div></div>
      <div class="sd-hero"><div class="stack"><div class="sd-h"></div><div class="sd-h w2"></div><div class="sd-p"></div><div class="sd-p w3"></div><div class="sd-btn" style="margin-top:6px"></div></div><div class="sd-art"></div></div>
      <div class="sd-cards"><div></div><div></div><div></div></div>`],
    ["E-commerce", `<div class="sd-nav"><div class="sd-logo"></div><div class="sd-links"><i></i><i></i><i></i></div><div class="sd-cart"></div></div>
      <div class="sd-banner"><div class="bar"></div><div class="sd-btn" style="background:#fff;width:54px"></div></div>
      <div class="sd-products">${[["#22d3ee", "#2f6bff"], ["#a78bfa", "#ec4899"], ["#34d399", "#22d3ee"], ["#fbbf24", "#fb7185"]]
        .map(([a, b]) => `<div class="sd-prod"><div class="img" style="--a:${a};--b:${b}"></div><span class="bar"></span><div class="price"></div></div>`)
        .join("")}</div>`],
    ["Landing Page", `<div class="sd-nav"><div class="sd-logo"></div><div class="sd-btn"></div></div>
      <div class="sd-center"><div class="sd-h"></div><div class="sd-h w2"></div><div class="sd-p"></div><div class="sd-btn"></div></div>
      <div class="sd-feats"><div></div><div></div><div></div><div></div></div>`],
  ];
  return `<div class="mock-wrap" data-browser><div class="mock-glow"></div><div class="mock">
  <div class="browser-chrome"><div class="dots"><i></i><i></i><i></i></div><div class="url">${icon("shield")}<span data-url>yourbusiness.com</span></div></div>
  <div class="browser-tabs" role="tablist" aria-label="Website examples">${demos
    .map(([n], i) => `<button class="btab${i === 0 ? " is-active" : ""}" role="tab" aria-selected="${i === 0}" type="button" data-btab="${i}">${n}</button>`)
    .join("")}</div>
  <div class="browser-view">${demos.map(([n, h], i) => `<div class="site-demo${i === 0 ? " is-active" : ""}" data-demo="${i}" aria-label="${n} website layout example" role="img">${h}</div>`).join("")}</div>
</div></div>`;
}

const appScreens = {
  shop: `<div class="app"><div class="app-h"><span>Discover</span><span class="av"></span></div>
    <div class="app-hero"><small>Festive offer</small><b>Up to 40% off</b></div>
    <div class="app-grid">${[["#22d3ee", "#2f6bff"], ["#a78bfa", "#ec4899"], ["#34d399", "#22d3ee"], ["#fbbf24", "#fb7185"]]
      .map(([a, b]) => `<div class="tile"><div class="img" style="--a:${a};--b:${b}"></div><span class="bar" style="width:70%;height:6px"></span></div>`)
      .join("")}</div><div class="app-tabbar"><i></i><i></i><i></i><i></i></div></div>`,
  dash: `<div class="app"><div class="app-h"><span>Overview</span><span class="av"></span></div>
    <div class="app-card"><small style="color:var(--dim)">This week</small><b style="display:block;color:#fff;font:600 1.9em/1.2 var(--font-display)">Orders ↑</b>
    <div class="app-chart" style="margin-top:10px">${[40, 62, 48, 75, 58, 88, 70].map((h) => `<b style="--h:${h}%"></b>`).join("")}</div></div>
    <div class="app-card app-row"><div class="thumb"></div><div class="lines"><span class="bar t" style="width:80%"></span><span class="bar" style="width:55%"></span></div></div>
    <div class="app-card app-row"><div class="thumb" style="--a:#a78bfa;--b:#ec4899"></div><div class="lines"><span class="bar t" style="width:70%"></span><span class="bar" style="width:45%"></span></div></div>
    <div class="app-tabbar"><i></i><i></i><i></i><i></i></div></div>`,
  book: `<div class="app"><div class="app-h"><span>Book a slot</span><span class="av"></span></div>
    <div class="app-card"><div class="app-cal">${["M", "T", "W", "T", "F", "S", "S"].map((d) => `<span>${d}</span>`).join("")}${[12, 13, 14, 15, 16, 17, 18]
      .map((d) => `<span class="${d === 15 ? "on" : ""}">${d}</span>`)
      .join("")}</div></div>
    <div class="app-slots"><span>10:00</span><span class="on">11:30</span><span>13:00</span><span>14:30</span><span>16:00</span><span>17:30</span></div>
    <div class="app-card app-row"><div class="thumb" style="--a:#34d399;--b:#22d3ee"></div><div class="lines"><span class="bar t" style="width:75%"></span><span class="bar" style="width:50%"></span></div></div>
    <div class="app-btn">Confirm booking</div></div>`,
};

export const phone = (screen, extra = "") =>
  `<div class="phone" ${extra} role="img" aria-label="Mobile app interface example"><div class="phone-screen">${appScreens[screen]}</div></div>`;

export const phonesShowcase = () =>
  `<div class="mock-wrap"><div class="mock-glow" style="inset:10% 15% auto"></div><div class="phones">${phone("dash", 'data-parallax="0.06"')}${phone("shop")}${phone(
    "book",
    'data-parallax="0.06"'
  )}</div></div>`;

export function supportConsole() {
  return `<div class="mock-wrap"><div class="mock-glow"></div><div class="mock" data-reveal="scale"><span class="sample-badge">Illustrative</span>
  <div class="console">
    <div class="console-side"><h5>Channels</h5>
      <div class="chan">${icon("call")}Voice<em>4</em></div>
      <div class="chan">${icon("mail")}Email<em>12</em></div>
      <div class="chan is-on">${icon("message")}Live chat<em>3</em></div>
    </div>
    <div class="console-main">
      <div class="chat-head"><span class="av">AK</span><div><strong>Order enquiry</strong><small>● Customer online</small></div></div>
      <div class="chat" data-chat>
        <div class="msg in">Hi! My order hasn't arrived yet. Can you check the status?</div>
        <div class="msg out">Happy to help! I can see your order — it's out for delivery and should reach you by 6 PM today.</div>
        <div class="msg in">That's great, thank you. Can I change the delivery address?</div>
        <div class="msg out">Done ✓ I've updated the address and shared a confirmation by email.</div>
        <div class="typing"><i></i><i></i><i></i></div>
      </div>
      <div class="chat-input">Type a reply…<i>${icon("arrowUpRight")}</i></div>
    </div>
    <div class="console-right"><h5>Live performance</h5>
      <div class="kpi"><small>First response</small><b>Under target</b><div class="track"><i style="--w:82%"></i></div></div>
      <div class="kpi"><small>Resolution rate</small><b>Tracked daily</b><div class="track"><i style="--w:74%"></i></div></div>
      <div class="kpi"><small>Quality score</small><b>QA reviewed</b><div class="track"><i style="--w:90%"></i></div></div>
    </div>
  </div></div></div>`;
}

export function excelMockup() {
  const rows = [
    ["North", "18,40,000", "20,00,000", 92, "warn"],
    ["South", "24,15,000", "22,00,000", 110, "ok"],
    ["East", "12,60,000", "16,00,000", 79, "low"],
    ["West", "21,90,000", "21,00,000", 104, "ok"],
    ["Central", "15,30,000", "15,50,000", 99, "warn"],
  ];
  const seg = (len, off, color) => `<circle class="seg" r="40" cx="50" cy="50" stroke="${color}" data-len="${len}" stroke-dashoffset="${-off}" transform="rotate(-90 50 50)"/>`;
  const C = 2 * Math.PI * 40;
  return `<div class="mock-wrap"><div class="mock-glow" style="background:radial-gradient(closest-side,rgba(52,211,153,.35),transparent)"></div><div class="mock" data-reveal="scale" data-xl><span class="sample-badge">Sample data</span>
  <div class="xl">
    <div class="xl-sheet">
      <div class="xl-bar"><b>fx</b><span>=SUMIFS(<em>Sales[Amount]</em>, <em>Sales[Region]</em>, A2, <em>Sales[Month]</em>, $H$1)</span></div>
      <table class="xl-table"><thead><tr><th style="width:24%">Region</th><th>Sales (₹)</th><th>Target (₹)</th><th>Trend</th><th style="width:16%">Achieved</th></tr></thead><tbody>
      ${rows
        .map(
          ([r, s, t, p, c], i) =>
            `<tr><td>${r}</td><td class="n${i === 1 ? " sel" : ""}">${s}</td><td class="n">${t}</td><td class="n">${p >= 100 ? "▲" : "▼"}</td><td class="n pct ${c}">${p}%</td></tr>`
        )
        .join("")}
      <tr class="total"><td>Total</td><td class="n">92,35,000</td><td class="n">94,50,000</td><td class="n">—</td><td class="n">98%</td></tr>
      </tbody></table>
      <div class="xl-tabs"><span class="on">Dashboard</span><span>Sales Data</span><span>Targets</span><span>MIS</span></div>
    </div>
    <div class="xl-dash">
      <div class="xl-kpis"><div class="kpi"><small>Monthly sales</small><b>₹92.4L</b></div><div class="kpi"><small>Target achieved</small><b>98%</b></div></div>
      <div class="chart-box"><h6><span>Sales by region</span><span>₹ lakh</span></h6><div class="vbars">${[
        ["N", 74], ["S", 96], ["E", 52], ["W", 88], ["C", 62],
      ]
        .map(([l, h]) => `<div class="col"><i style="--h:${h}%"></i><small>${l}</small></div>`)
        .join("")}</div></div>
      <div class="chart-box"><h6><span>Category mix</span></h6><div class="donut-wrap">
        <svg class="donut" viewBox="0 0 100 100" aria-hidden="true"><circle r="40" cx="50" cy="50" stroke="rgba(255,255,255,.06)"/>${seg(C * 0.42, 0, "#2F6BFF")}${seg(C * 0.28, C * 0.42, "#22D3EE")}${seg(
    C * 0.18,
    C * 0.7,
    "#8B5CF6"
  )}${seg(C * 0.12, C * 0.88, "#34D399")}</svg>
        <div class="legend"><span><i style="background:#2F6BFF"></i>Products 42%</span><span><i style="background:#22D3EE"></i>Services 28%</span><span><i style="background:#8B5CF6"></i>Subscriptions 18%</span><span><i style="background:#34D399"></i>Other 12%</span></div>
      </div></div>
    </div>
  </div></div></div>`;
}

export function hrmsDashboard() {
  const people = [
    ["Aarav Mehta", "AM", "Engineering", "on", "Present", "#2f6bff"],
    ["Priya Nair", "PN", "Finance", "remote", "Remote", "#8b5cf6"],
    ["Rohan Gill", "RG", "Sales", "on", "Present", "#0ea5e9"],
    ["Simran Kaur", "SK", "HR", "leave-c", "On leave", "#ec4899"],
  ];
  const leaves = [
    ["Neha Sharma", "NS", "Casual leave · 2 days", "#f59e0b"],
    ["Karan Malhotra", "KM", "Sick leave · 1 day", "#10b981"],
    ["Ishita Verma", "IV", "Earned leave · 4 days", "#6366f1"],
  ];
  const nav = [
    ["layout", "Dashboard", true], ["users", "Employees"], ["clock", "Attendance"], ["calendar", "Leave"], ["wallet", "Payroll"], ["userPlus", "Recruitment"], ["target", "Performance"], ["bars", "Reports"],
  ];
  const C = 2 * Math.PI * 40;
  return `<div class="mock-wrap"><div class="mock-glow" style="background:radial-gradient(closest-side,rgba(139,92,246,.45),transparent)"></div><div class="mock" data-hr><span class="sample-badge">Sample data</span>
  <div class="hr">
    <aside class="hr-side"><div class="hr-brand">${markSVG({ id: "hrm" })}Velto HRMS</div>${nav
      .map(([i, l, on]) => `<button type="button" class="hr-nav${on ? " is-on" : ""}" data-hr-nav>${icon(i)}${l}</button>`)
      .join("")}</aside>
    <div class="hr-main">
      <div class="hr-top"><div><h4>Good morning, HR Team</h4><small>Here's what's happening across your organisation today.</small></div><div class="hr-search">${icon("search")}Search employees…</div></div>
      <div class="hr-kpis">
        <div class="kpi"><small>Total employees</small><b data-count="248">248</b><span class="delta">+6 this month</span></div>
        <div class="kpi"><small>Present today</small><b data-count="231">231</b><span class="delta">93% attendance</span></div>
        <div class="kpi"><small>On leave</small><b data-count="9">9</b><span class="delta" style="color:var(--amber)">3 pending approval</span></div>
        <div class="kpi"><small>Open positions</small><b data-count="6">6</b><span class="delta" style="color:#93c5fd">42 applicants</span></div>
      </div>
      <div class="hr-row">
        <div class="chart-box"><h6><span>Weekly attendance</span><span>%</span></h6><div class="vbars" data-vbars>${[
          ["Mon", 92], ["Tue", 95], ["Wed", 90], ["Thu", 96], ["Fri", 88], ["Sat", 70],
        ]
          .map(([l, h]) => `<div class="col"><i style="--h:${h}%"></i><small>${l}</small></div>`)
          .join("")}</div></div>
        <div class="chart-box"><h6><span>Leave requests</span><span style="color:var(--amber)">Pending</span></h6>${leaves
          .map(
            ([n, a, t, c]) =>
              `<div class="leave" data-leave><span class="av" style="background:${c}">${a}</span><div><strong>${n}</strong><small>${t}</small></div><div class="acts"><button type="button" class="ok" aria-label="Approve ${n}" data-act="approved">${icon(
                "check"
              )}</button><button type="button" class="no" aria-label="Reject ${n}" data-act="rejected">${icon("close")}</button></div></div>`
          )
          .join("")}</div>
      </div>
      <div class="hr-row r2">
        <div class="chart-box"><h6><span>Payroll summary</span><span>This month</span></h6><div class="donut-wrap">
          <svg class="donut" viewBox="0 0 100 100" aria-hidden="true"><circle r="40" cx="50" cy="50" stroke="rgba(255,255,255,.06)"/><circle class="seg" r="40" cx="50" cy="50" stroke="#8B5CF6" data-len="${C * 0.72}" transform="rotate(-90 50 50)"/><circle class="seg" r="40" cx="50" cy="50" stroke="#22D3EE" data-len="${C * 0.18}" stroke-dashoffset="${-C * 0.72}" transform="rotate(-90 50 50)"/><circle class="seg" r="40" cx="50" cy="50" stroke="#34D399" data-len="${C * 0.1}" stroke-dashoffset="${-C * 0.9}" transform="rotate(-90 50 50)"/></svg>
          <div class="pay-rows" style="flex:1"><div><span>Net salaries</span><b>72%</b></div><div><span>Statutory (PF/ESI)</span><b>18%</b></div><div><span>Reimbursements</span><b>10%</b></div><div><span>Status</span><b style="color:var(--green)">Processed</b></div></div>
        </div></div>
        <div class="chart-box"><h6><span>Employees</span><span>View all →</span></h6><table class="emp-table"><thead><tr><th>Name</th><th>Status</th><th>Department</th></tr></thead><tbody>${people
          .map(([n, a, d, c, s, col]) => `<tr><td><span class="av" style="background:${col}">${a}</span>${n}</td><td><span class="chip ${c}">${s}</span></td><td>${d}</td></tr>`)
          .join("")}</tbody></table></div>
      </div>
    </div>
  </div></div></div>`;
}

export function heroVisual() {
  return `<div class="orb-stage" data-tilt aria-hidden="true">
  <div class="orb-3d">
    <div class="rings"><div class="ring r2"><i></i></div><div class="ring r1"><i></i></div><div class="ring r3"><i></i></div></div>
    <div class="orb"></div>
    <div class="orb-core">${markSVG({ id: "orbm" })}</div>
  </div>
  <div class="float-card fc1">${ico("checkCircle", "green")}<div>Website launched<small>Responsive · SEO-ready</small></div></div>
  <div class="float-card fc2">${ico("zap", "violet")}<div>Workflow automated<small>Reports run themselves</small></div><div class="mini-bars"><b></b><b></b><b></b><b></b><b></b></div></div>
  <div class="float-card fc3">${ico("users", "cyan")}<div>Payroll processed<small>HRMS · on time</small></div></div>
</div>`;
}
