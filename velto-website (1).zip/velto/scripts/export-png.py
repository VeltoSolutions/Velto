# Renders PNG versions of the brand files with headless Chromium (Playwright) + builds favicon.ico.
# One-time asset export — outputs are committed in assets/brand, so deployment needs no Python.
import pathlib, subprocess
from playwright.sync_api import sync_playwright
D = pathlib.Path(__file__).resolve().parent.parent / "assets" / "brand"

def svg_page(svg, w, h, bg="transparent"):
    return f'<html><body style="margin:0;background:{bg}"><div style="width:{w}px;height:{h}px">{svg.replace("<svg ", f"<svg style=\"width:{w}px;height:{h}px;display:block\" ",1)}</div></body></html>'

jobs = [  # (svg file, out png, w, h)
    ("velto-logo-dark.svg", "velto-logo-dark.png", 1312, 384),
    ("velto-logo-light.svg", "velto-logo-light.png", 1312, 384),
    ("velto-logo-stacked-dark.svg", "velto-logo-stacked-dark.png", 1080, 1080),
    ("velto-logo-stacked-light.svg", "velto-logo-stacked-light.png", 1080, 1080),
    ("velto-symbol.svg", "velto-symbol.png", 512, 512),
    ("velto-symbol-dark.svg", "velto-symbol-dark.png", 512, 512),
    ("velto-symbol-light.svg", "velto-symbol-light.png", 512, 512),
    ("favicon.svg", "icon-512.png", 512, 512),
    ("favicon.svg", "icon-192.png", 192, 192),
    ("favicon.svg", "apple-touch-icon.png", 180, 180),
    ("favicon.svg", "favicon-48.png", 48, 48),
    ("favicon.svg", "favicon-32.png", 32, 32),
    ("favicon.svg", "favicon-16.png", 16, 16),
]
with sync_playwright() as p:
    b = p.chromium.launch()
    for src, out, w, h in jobs:
        pg = b.new_page(viewport={"width": w, "height": h})
        pg.set_content(svg_page((D / src).read_text(), w, h))
        pg.screenshot(path=str(D / out), omit_background=True, clip={"x": 0, "y": 0, "width": w, "height": h})
        pg.close()
    pg = b.new_page(viewport={"width": 1200, "height": 630})
    pg.set_content((pathlib.Path(__file__).resolve().parent / "og-source.html").read_text())
    pg.screenshot(path=str(D / "og-image.png"))
    b.close()
subprocess.run(["convert", str(D/"favicon-16.png"), str(D/"favicon-32.png"), str(D/"favicon-48.png"), str(D/"favicon.ico")], check=True)
for f in ["favicon-16.png", "favicon-32.png", "favicon-48.png"]:
    (D / f).unlink()
print("✓ PNG brand assets + favicon.ico exported")
