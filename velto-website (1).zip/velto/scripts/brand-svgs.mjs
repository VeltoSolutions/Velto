// Writes all vector brand files into assets/brand (run: node scripts/brand-svgs.mjs)
import fs from "node:fs";
import { lockupFile, stackedFile, symbolFile, faviconSVG, brand } from "../src/brand.mjs";
const D = new URL("../assets/brand/", import.meta.url).pathname;
fs.mkdirSync(D, { recursive: true });
const files = {
  "velto-logo-dark.svg": lockupFile({ text: brand.white, node: "#FFFFFF" }),            // for dark backgrounds
  "velto-logo-light.svg": lockupFile({ text: brand.navy, node: brand.navy, back: ".8" }), // for light backgrounds
  "velto-logo-dark-bg.svg": lockupFile({ text: brand.white, node: "#FFFFFF", bg: brand.ink }),
  "velto-logo-stacked-dark.svg": stackedFile({ text: brand.white, node: "#FFFFFF", bg: brand.ink }),
  "velto-logo-stacked-light.svg": stackedFile({ text: brand.navy, node: brand.navy, bg: "#FFFFFF", back: ".8" }),
  "velto-symbol.svg": symbolFile({ node: "#FFFFFF", bg: brand.ink, radius: 12, pad: 6 }),
  "velto-symbol-light.svg": symbolFile({ node: brand.navy, back: ".8" }),
  "velto-symbol-dark.svg": symbolFile({ node: "#FFFFFF" }),
  "favicon.svg": faviconSVG(),
};
for (const [n, c] of Object.entries(files)) fs.writeFileSync(D + n, c);
// OG image source (rendered to PNG by scripts/export-png.py)
const og = `<!doctype html><html><head><style>
body{margin:0;width:1200px;height:630px;background:#05060A;font-family:Inter,Segoe UI,Arial,sans-serif;overflow:hidden;position:relative}
.g1{position:absolute;width:700px;height:700px;right:-200px;top:-260px;border-radius:50%;background:radial-gradient(closest-side,rgba(47,107,255,.75),transparent)}
.g2{position:absolute;width:600px;height:600px;left:-220px;bottom:-320px;border-radius:50%;background:radial-gradient(closest-side,rgba(139,92,246,.6),transparent)}
.grid{position:absolute;inset:0;background-image:linear-gradient(rgba(255,255,255,.05) 1px,transparent 1px),linear-gradient(90deg,rgba(255,255,255,.05) 1px,transparent 1px);background-size:60px 60px;-webkit-mask-image:radial-gradient(ellipse at 40% 50%,#000 20%,transparent 75%)}
.c{position:absolute;left:90px;top:120px;right:90px}
h1{margin:60px 0 0;color:#F5F7FB;font-size:68px;line-height:1.05;letter-spacing:-2.5px;font-weight:600}
h1 span{background:linear-gradient(100deg,#22D3EE,#5B8CFF 45%,#A78BFA);-webkit-background-clip:text;color:transparent}
p{color:#A1A9BE;font-size:26px;margin:26px 0 0}
.url{position:absolute;left:90px;bottom:60px;color:#8EA6FF;font-size:22px;letter-spacing:.04em}
</style></head><body><div class="g1"></div><div class="g2"></div><div class="grid"></div>
<div class="c">${lockupFile({ text: brand.white, node: "#FFFFFF" }).replace('width="656" height="192"', 'width="300" height="88"')}
<h1>Technology That Moves<br><span>Business Forward.</span></h1>
<p>Web &amp; App Development · Custom Software · BPO · Excel Automation · HRMS</p></div>
<div class="url">velto.co.in</div></body></html>`;
fs.writeFileSync(new URL("./og-source.html", import.meta.url).pathname, og);
console.log("✓ wrote", Object.keys(files).length, "SVG brand files");
