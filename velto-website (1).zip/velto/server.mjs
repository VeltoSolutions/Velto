// Standalone production server (for a VPS / any Node 18+ host) and local preview.
// Serves ./dist with clean URLs and handles POST /api/contact.
//   npm run build && npm start        →  http://localhost:3000
import http from "node:http";
import fs from "node:fs";
import path from "node:path";
import { handleContact, clientIp } from "./lib/contact.mjs";

// Load .env (simple KEY=VALUE parser) if present
const envFile = path.join(path.dirname(new URL(import.meta.url).pathname), ".env");
if (fs.existsSync(envFile)) {
  for (const line of fs.readFileSync(envFile, "utf8").split(/\r?\n/)) {
    const m = /^\s*([A-Z0-9_]+)\s*=\s*(.*)\s*$/.exec(line);
    if (m && !line.trim().startsWith("#") && process.env[m[1]] === undefined) process.env[m[1]] = m[2].replace(/^["']|["']$/g, "");
  }
}

const DIST = path.join(path.dirname(new URL(import.meta.url).pathname), "dist");
const PORT = Number(process.env.PORT || 3000);
const TYPES = { ".html": "text/html; charset=utf-8", ".css": "text/css; charset=utf-8", ".js": "text/javascript; charset=utf-8", ".svg": "image/svg+xml", ".png": "image/png", ".ico": "image/x-icon", ".webp": "image/webp", ".avif": "image/avif", ".jpg": "image/jpeg", ".json": "application/json", ".xml": "application/xml", ".txt": "text/plain; charset=utf-8", ".webmanifest": "application/manifest+json", ".woff2": "font/woff2" };
const SEC = { "X-Content-Type-Options": "nosniff", "Referrer-Policy": "strict-origin-when-cross-origin", "X-Frame-Options": "SAMEORIGIN", "Permissions-Policy": "camera=(), microphone=(), geolocation=()" };

const send = (res, status, body, headers = {}) => { res.writeHead(status, { ...SEC, ...headers }); res.end(body); };

http.createServer(async (req, res) => {
  const url = new URL(req.url, "http://localhost");
  if (url.pathname === "/api/contact") {
    if (req.method !== "POST") return send(res, 405, JSON.stringify({ ok: false, error: "Method not allowed." }), { "Content-Type": "application/json", Allow: "POST" });
    let raw = "";
    for await (const chunk of req) { raw += chunk; if (raw.length > 20000) return send(res, 413, JSON.stringify({ ok: false, error: "Request too large." }), { "Content-Type": "application/json" }); }
    let body = null;
    try { body = JSON.parse(raw); } catch {}
    const { status, json } = await handleContact({ body, ip: clientIp(req.headers, req.socket.remoteAddress), origin: req.headers.origin, host: req.headers["x-forwarded-host"] || req.headers.host, referer: req.headers.referer });
    return send(res, status, JSON.stringify(json), { "Content-Type": "application/json", "Cache-Control": "no-store" });
  }
  // Redirect /path → /path/ for directories (clean URLs)
  let rel = decodeURIComponent(url.pathname);
  let file = path.join(DIST, rel);
  if (!file.startsWith(DIST)) return send(res, 400, "Bad request");
  try {
    const st = fs.statSync(file);
    if (st.isDirectory()) {
      if (!rel.endsWith("/")) return send(res, 301, "", { Location: rel + "/" + url.search });
      file = path.join(file, "index.html");
    }
  } catch {
    if (fs.existsSync(file + ".html")) file += ".html";
    else return send(res, 404, fs.readFileSync(path.join(DIST, "404.html")), { "Content-Type": TYPES[".html"] });
  }
  if (!fs.existsSync(file)) return send(res, 404, fs.readFileSync(path.join(DIST, "404.html")), { "Content-Type": TYPES[".html"] });
  const ext = path.extname(file);
  const cache = rel.startsWith("/assets/") ? "public, max-age=31536000, immutable" : "public, max-age=0, must-revalidate";
  send(res, 200, fs.readFileSync(file), { "Content-Type": TYPES[ext] || "application/octet-stream", "Cache-Control": cache });
}).listen(PORT, () => console.log(`Velto running at http://localhost:${PORT}`));
