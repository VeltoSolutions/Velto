// Netlify Function (v2) — POST /api/contact
// Email credentials are read from Netlify environment variables on the server only.
import { handleContact } from "../../lib/contact.mjs";

const json = (status, body, extra = {}) =>
  new Response(JSON.stringify(body), { status, headers: { "Content-Type": "application/json", "Cache-Control": "no-store", ...extra } });

export default async (req, context) => {
  if (req.method !== "POST") return json(405, { ok: false, error: "Method not allowed." }, { Allow: "POST" });

  const raw = await req.text();
  if (raw.length > 20000) return json(413, { ok: false, error: "Request too large." });
  let body = null;
  try { body = JSON.parse(raw); } catch {}

  const { status, json: out } = await handleContact({
    body,
    ip: context?.ip || req.headers.get("x-nf-client-connection-ip") || "unknown",
    origin: req.headers.get("origin") || undefined,
    host: new URL(req.url).host,
    referer: req.headers.get("referer") || undefined,
  });
  return json(status, out);
};

export const config = { path: "/api/contact" };
