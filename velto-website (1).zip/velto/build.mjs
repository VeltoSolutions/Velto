// Velto static site generator — zero dependencies (Node 18+).
// Usage: node build.mjs   →  outputs the production site to ./dist
import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";
import { page } from "./src/layout.mjs";
import { site, services } from "./src/data.mjs";
import { faviconSVG } from "./src/brand.mjs";

import home from "./src/pages/home.mjs";
import about from "./src/pages/about.mjs";
import servicesPage from "./src/pages/services.mjs";
import solutions from "./src/pages/solutions.mjs";
import contact from "./src/pages/contact.mjs";
import web from "./src/pages/web-development.mjs";
import app from "./src/pages/app-development.mjs";
import bpo from "./src/pages/bpo.mjs";
import excel from "./src/pages/excel-automation.mjs";
import hrms from "./src/pages/hrms.mjs";
import { servicePage } from "./src/pages/service-template.mjs";
import { privacy, notFound } from "./src/pages/legal.mjs";

const ROOT = path.dirname(new URL(import.meta.url).pathname);
const OUT = path.join(ROOT, "dist");

const dedicated = { "web-development": web, "app-development": app, bpo, "excel-automation": excel, hrms };
const servicePages = services.map((s) => dedicated[s.slug] || servicePage(s));
const pages = [home, about, servicesPage, ...servicePages, solutions, contact, privacy, notFound];

// cache-busting version from asset contents
const hash = crypto.createHash("md5");
for (const f of ["assets/css/styles.css", "assets/js/main.js"]) hash.update(fs.readFileSync(path.join(ROOT, f)));
const V = hash.digest("hex").slice(0, 10);

fs.rmSync(OUT, { recursive: true, force: true });
fs.mkdirSync(OUT, { recursive: true });

const write = (rel, content) => {
  const file = path.join(OUT, rel);
  fs.mkdirSync(path.dirname(file), { recursive: true });
  fs.writeFileSync(file, content);
};

for (const p of pages) {
  const jsonLd = [...(p.jsonLd || [])];
  if (p.service) {
    jsonLd.push({
      "@context": "https://schema.org",
      "@type": "Service",
      name: p.service.title,
      serviceType: p.service.title,
      description: p.description,
      provider: { "@id": site.url + "/#organization" },
      areaServed: "IN",
      url: site.url + p.path,
    });
  }
  if (p.path !== "/" && p.path !== "/404.html") {
    const parts = p.path.split("/").filter(Boolean);
    jsonLd.push({
      "@context": "https://schema.org",
      "@type": "BreadcrumbList",
      itemListElement: [{ name: "Home", path: "/" }, ...parts.map((_, i) => ({ path: "/" + parts.slice(0, i + 1).join("/") + "/" }))].map((c, i, arr) => ({
        "@type": "ListItem",
        position: i + 1,
        name: c.name || (i === arr.length - 1 ? p.title.split(/ [—|-] /)[0] : pages.find((x) => x.path === c.path)?.title.split(/ [—|-] /)[0] || c.path),
        item: site.url + c.path,
      })),
    });
  }
  if (p.path === "/") jsonLd.push({ "@context": "https://schema.org", "@type": "WebSite", name: "Velto", url: site.url, publisher: { "@id": site.url + "/#organization" } });

  const html = page({ ...p, body: p.body(), jsonLd }).replace(/__V__/g, V);
  const rel = p.path.endsWith(".html") ? p.path : path.join(p.path, "index.html");
  write(rel, html);
}

// static assets
fs.cpSync(path.join(ROOT, "assets"), path.join(OUT, "assets"), { recursive: true });
write("favicon.svg", faviconSVG());
for (const f of ["favicon.ico", "apple-touch-icon.png", "icon-192.png", "icon-512.png"]) {
  const src = path.join(ROOT, "assets/brand", f);
  if (fs.existsSync(src)) fs.copyFileSync(src, path.join(OUT, f));
}
write(
  "site.webmanifest",
  JSON.stringify(
    {
      name: "Velto",
      short_name: "Velto",
      description: site.tagline,
      start_url: "/",
      display: "standalone",
      background_color: "#05060A",
      theme_color: "#05060A",
      icons: [
        { src: "/icon-192.png", sizes: "192x192", type: "image/png" },
        { src: "/icon-512.png", sizes: "512x512", type: "image/png" },
      ],
    },
    null,
    2
  )
);

// SEO files
const today = new Date().toISOString().slice(0, 10);
const indexable = pages.filter((p) => !p.noindex);
write(
  "sitemap.xml",
  `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${indexable
    .map(
      (p) =>
        `  <url><loc>${site.url}${p.path}</loc><lastmod>${today}</lastmod><changefreq>${p.path === "/" ? "weekly" : "monthly"}</changefreq><priority>${
          p.path === "/" ? "1.0" : p.path.startsWith("/services/") || p.path === "/contact/" ? "0.8" : p.path === "/privacy/" ? "0.3" : "0.7"
        }</priority></url>`
    )
    .join("\n")}\n</urlset>\n`
);
write("robots.txt", `User-agent: *\nAllow: /\nDisallow: /api/\n\nSitemap: ${site.url}/sitemap.xml\n`);

console.log(`✓ Built ${pages.length} pages → dist/ (assets v${V})`);
